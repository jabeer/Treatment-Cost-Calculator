//uat
//licensefile: settings/license.key
mHealth = {};
mHealth.models = {};
mHealth.controllers = {};
mHealth.environment= null; //Setting the Environment 
mHealth.debugOption= true; // set to true for DEV AND QA BUILD, false or null for PROD AND UAT
mHealth.service_timeout =100000;//100000 milliseconds = 100 seconds...
mHealth.pegadateformat ='yyyymmdd"T"HHMMss".000 GMT"';
mHealth.dateformat ='yyyymmdd';
mHealth.challengeDateFormat='dddd, mmm d, yyyy';
mHealth.messageDateFormat='mm/dd/yyyy hh:MM TT';
mHealth.heightdateformat='mm/dd/yyyy hh:mm TT';
mHealth.datedashformat = 'yyyy-mm-dd';
mHealth.appsource ='112';
mHealth.externalHelpDesk = '877-719-9004';
mHealth.IOSURL= 'openurl://external?url=';
mHealth.delay        = null;
mHealth.DEVBASEURL  = 'http://secure.uat.alerehealth.com:13085/api/';
mHealth.QABASEURL   = 'https://secure.qa.alerehealth.com:13084/api/';
mHealth.UATBASEURL  = 'https://secure.uat.alerehealth.com:13086/api/';
mHealth.PRODBASEURL = 'https://secure.alerehealth.com:13087/api/';

mHealth.uat = {
    tou_get_url             : mHealth.UATBASEURL+'tou',
	authtoken_get_url       : mHealth.UATBASEURL+'gettoken',
	healthdata_url          : mHealth.UATBASEURL+'healthdata/',
	medicaldevices_url      : mHealth.UATBASEURL+'medicaldevices/',
	message_get_url         : mHealth.UATBASEURL+'welcome/',
	medication_url          : mHealth.UATBASEURL+'medications/',
    medicationfromclaim_url : mHealth.UATBASEURL+'medicationfromclaim/',
	condition_url           : mHealth.UATBASEURL+'conditions/',
	challenge_json_url      : mHealth.UATBASEURL+'challenge/',
	challenge_details_url   : mHealth.UATBASEURL+'challengedetails/',
	challenge_response_url  : mHealth.UATBASEURL+'challengeresponses/',
	recommendation_json_url : mHealth.UATBASEURL+'recommendation/',
	event_json_url          : mHealth.UATBASEURL+'events/',
	searchcondition_url     : mHealth.UATBASEURL+'conditions/search',
    searchindexcondition_url: mHealth.UATBASEURL+'masterconditions?filter=',
    profile_url             : mHealth.UATBASEURL+'profile/',
    messageheaders_url      : mHealth.UATBASEURL+'mc/message-headers',
    messagedetails_url      : mHealth.UATBASEURL+'mc/messages/',
    messagefeedback_url     : mHealth.UATBASEURL+'mc/user-feedback',
    healthwise_url          : mHealth.UATBASEURL+'health-articles/hwMCnt?id=healthwise://',
    mobile_app_config_url   : mHealth.UATBASEURL+'mobile-app-features-configuration',
    news_unread_count_url	: mHealth.UATBASEURL+'news/unread-article-cnt',
    news_url                : mHealth.UATBASEURL+'news/headlines',
    newsdetail_url          : mHealth.UATBASEURL+'news/articles?articleid=',
    registration_url        : "https://portal.uat.alerehealth.com/portal/MobileRegistration",
    dcpappname              : 'Apollo Portal Challenges Dashboard',
    emailTo                 : "c2dm@alere.com",
    emailCC                 : "",
    emailSubject            : " Feedback ",
};

mHealth.dev = {
	tou_get_url             : mHealth.DEVBASEURL+'tou',
	authtoken_get_url       : mHealth.DEVBASEURL+'gettoken',
	healthdata_url          : mHealth.DEVBASEURL+'healthdata/',
	medicaldevices_url      : mHealth.DEVBASEURL+'medicaldevices/',
	message_get_url         : mHealth.DEVBASEURL+'welcome/',
	medication_url          : mHealth.DEVBASEURL+'medications/',
    medicationfromclaim_url : mHealth.DEVBASEURL+'medicationfromclaim/',
	condition_url           : mHealth.DEVBASEURL+'conditions/',
	challenge_json_url      : mHealth.DEVBASEURL+'challenge/',
	challenge_details_url   : mHealth.DEVBASEURL+'challengedetails/',
	challenge_response_url  : mHealth.DEVBASEURL+'challengeresponses/',
	recommendation_json_url : mHealth.DEVBASEURL+'recommendation/',
	event_json_url          : mHealth.DEVBASEURL+'events/',
	searchcondition_url     : mHealth.DEVBASEURL+'conditions/search',
    searchindexcondition_url: mHealth.DEVBASEURL+'masterconditions?filter=',
    profile_url             : mHealth.DEVBASEURL+'profile/',
    messageheaders_url      : mHealth.DEVBASEURL+'mc/message-headers',
    messagedetails_url      : mHealth.DEVBASEURL+'mc/messages/',
    messagefeedback_url     : mHealth.DEVBASEURL+'mc/user-feedback',
    healthwise_url          : mHealth.DEVBASEURL+'health-articles/hwMCnt?id=healthwise://',
    mobile_app_config_url   : mHealth.DEVBASEURL+'mobile-app-features-configuration',
    news_unread_count_url	: mHealth.DEVBASEURL+'news/unread-article-cnt',
    news_url                : mHealth.DEVBASEURL+'news/headlines',
    newsdetail_url          : mHealth.DEVBASEURL+'news/articles?articleid=',
    registration_url        : "http://portal.uat.alerehealth.com/portal/MobileRegistration",
    dcpappname              : 'Apollo Portal Challenges Dashboard',
    emailTo                 : "c2dm@alere.com",
    emailCC                 : "",
    emailSubject            : " Feedback ",
};
    
mHealth.prod = {
	tou_get_url             : mHealth.PRODBASEURL+'tou',
	authtoken_get_url       : mHealth.PRODBASEURL+'gettoken',
	healthdata_url          : mHealth.PRODBASEURL+'healthdata/',
	medicaldevices_url      : mHealth.PRODBASEURL+'medicaldevices/',
	message_get_url         : mHealth.PRODBASEURL+'welcome/',
	medication_url          : mHealth.PRODBASEURL+'medications/',
    medicationfromclaim_url : mHealth.PRODBASEURL+'medicationfromclaim/',
	condition_url           : mHealth.PRODBASEURL+'conditions/',
	challenge_json_url      : mHealth.PRODBASEURL+'challenge/',
	challenge_details_url   : mHealth.PRODBASEURL+'challengedetails/',
	challenge_response_url  : mHealth.PRODBASEURL+'challengeresponses/',
	recommendation_json_url : mHealth.PRODBASEURL+'recommendation/',
	event_json_url          : mHealth.PRODBASEURL+'events/',
    searchindexcondition_url: mHealth.PRODBASEURL+'masterconditions?filter=',
	 messageheaders_url     : mHealth.PRODBASEURL+'mc/message-headers',
    messagedetails_url      : mHealth.PRODBASEURL+'mc/messages/',
    messagefeedback_url     : mHealth.PRODBASEURL+'mc/user-feedback',    
    healthwise_url          : mHealth.PRODBASEURL+'health-articles/hwMCnt?id=healthwise://',
    mobile_app_config_url   : mHealth.PRODBASEURL+'mobile-app-features-configuration',
    profile_url             : mHealth.PRODBASEURL+'profile/',
    news_unread_count_url	: mHealth.PRODBASEURL+'news/unread-article-cnt',
    news_url                : mHealth.PRODBASEURL+'news/headlines',
    newsdetail_url          : mHealth.PRODBASEURL+'news/articles?articleid=',
    registration_url        : "https://portal.alerehealth.com/portal/MobileRegistration",
    dcpappname              : 'Apollo Portal Challenges Dashboard',
    emailTo                 : "feedback@myahealth.com",
    emailCC                 : "",
    emailSubject            : " Feedback ",
};
    
mHealth.qa = {
	tou_get_url             : mHealth.QABASEURL+'tou',
	authtoken_get_url       : mHealth.QABASEURL+'gettoken',
	healthdata_url          : mHealth.QABASEURL+'healthdata/',
	medicaldevices_url      : mHealth.QABASEURL+'medicaldevices/',
	message_get_url         : mHealth.QABASEURL+'welcome/',
	medication_url          : mHealth.QABASEURL+'medications/',
    medicationfromclaim_url : mHealth.QABASEURL+'medicationfromclaim/',
	condition_url           : mHealth.QABASEURL+'conditions/',
	challenge_json_url      : mHealth.QABASEURL+'challenge/',
	challenge_details_url   : mHealth.QABASEURL+'challengedetails/',
	challenge_response_url  : mHealth.QABASEURL+'challengeresponses/',
	recommendation_json_url : mHealth.QABASEURL+'recommendation/',
	event_json_url          : mHealth.QABASEURL+'events/',
    searchindexcondition_url: mHealth.QABASEURL+'masterconditions?filter=',
	profile_url             : mHealth.QABASEURL+'profile/',
    messageheader_url       : mHealth.QABASEURL+'mc/message-headers',
    healthwise_url          : mHealth.QABASEURL+'health-articles/hwMCnt?id=healthwise://',
    mobile_app_config_url   : mHealth.QABASEURL+'mobile-app-features-configuration',
    news_unread_count_url	: mHealth.QABASEURL+'news/unread-article-cnt',
    news_url                : mHealth.QABASEURL+'news/headlines',
    newsdetail_url          : mHealth.QABASEURL+'news/articles?articleid=',
    registration_url        : "https://portal.uat.alerehealth.com/portal/MobileRegistration",
    dcpappname              : 'Apollo Portal Challenges Dashboard',
    emailTo                 : "c2dm@alere.com",
    emailCC                 : "",
    emailSubject            : " Feedback ",

};