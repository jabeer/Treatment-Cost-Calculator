/**
 * Object : modelmapper
 * Model Mapper default settings
 **/
mHealth.modelmapper = {};
/**
 * Name    : MedicationPostMapper
 * Purpose : Method to create request body for Add Medications Post Service.
 * Params  : medicationId, startDate,dosage,freqId,sourceId
 * Returns : bodyContent
 **/
//TODO: Add the Parameter the medication Add Claim medication
mHealth.modelmapper.MedicationClaimAddMapper=function(medicationObject,medicationId,startDate,endDate,dosage,frequancy,frequencyOther,refillfrequency,refillFrequencyOther){
	var bodyContent = JSON.stringify([{
                                      "cdrRunid"        : medicationObject.cdrRunid,
                                      "dispDate"        : medicationObject.dispDate,
                                      "medicationID"    : medicationId,
                                      "medicationType"  : medicationObject.medicationType,
                                      "ndcId"           : medicationObject.ndcId,
                                      "rxClaimId"       : medicationObject.rxClaimId,
                                      "rxDaysSupply"    : medicationObject.rxDaysSupply,
                                      "rxQuantity"      : medicationObject.rxQuantity,
                                      "startDate"       : startDate,
                                      "endDate"         : endDate,
                                      "strength"        : "",
                                      "dosage"          : dosage,
                                      "freqId"          : frequancy,
                                      "freqDesc"        : frequencyOther,
                                      "otherFreq"       : frequencyOther,
                                      "refillFreqId"    : refillfrequency,
                                      "refillFrequencyOther" : refillFrequencyOther,
                                      "nextRefillDate"  : "",
                                      "complianceId"    : "",
                                      "complianceDesc"  : ""
                                      }]);
                                      return bodyContent;
};
/**
 * Name    : MedicationPostMapper
 * Purpose : Method to create request body for Add Medications Post Service.
 * Params  : medicationId, startDate,dosage,freqId,sourceId
 * Returns : bodyContent
 **/

mHealth.modelmapper.MedicationArchToAddMapper=function(medicationId,startDate,endDate,dosage,freqId,refillfrequency,sourceId,refillFrequencyOther,frequencyOther,participantMedId){
	
	
	
	var bodyContent = JSON.stringify([{
                                      "medicationID" : medicationId,
                                      "startDate"    : startDate,
                                      "endDate"      : endDate,
                                      "dosage"       : dosage,
                                      "freqId"       :freqId,
                                      "refillFreqId" :refillfrequency,
                                      "partMedId": participantMedId,
                                      "sourceId"     :sourceId,
                                      "complianceStatus" : "1",
                                      "otherFreq"            : frequencyOther,
                                      "refillFrequencyOther" : refillFrequencyOther
                                      }]);	
	return bodyContent;

};


/**
 * Name    : MedicationPostMapper
 * Purpose : Method to create request body for Add Medications Post Service.
 * Params  : medicationId, startDate,dosage,freqId,sourceId
 * Returns : bodyContent
 **/

mHealth.modelmapper.MedicationPostMapper=function(medicationId,startDate,endDate,dosage,freqId,refillfrequency,sourceId,refillFrequencyOther,frequencyOther){
	
	
	
	var bodyContent = JSON.stringify([{
                                      "medicationID" : medicationId,
                                      "startDate"    : startDate,
                                      "endDate"      : endDate,
                                      "dosage"       : dosage,
                                      "freqId"       :freqId,
                                      "refillFreqId" :refillfrequency,
                                      "sourceId"     :sourceId,
                                      "complianceStatus" : "1",
                                      "otherFreq"            : frequencyOther,
                                      "refillFrequencyOther" : refillFrequencyOther
                                      }]);	
	return bodyContent;
};



/**
 * Name    : MedicationUpdateMapper
 * Purpose : Method to create request body for Add Medications Post Service.
 * Params  : medicationId, startDate,dosage,freqId,sourceId
 * Returns : bodyContent
 **/

mHealth.modelmapper.MedicationUpdateMapper=function(partMedId,medicationId,startDate,endDate,dosage,freqId,refillfrequency,refillFrequencyOther,frequencyOther){
	var bodyContent = JSON.stringify([{
                                      "partMedId"     : partMedId,
                                      "medicationID"  : medicationId,
                                      "startDate"     : startDate,
                                      "endDate"       : endDate,
                                      "dosage"        : dosage,
                                      "freqId"        :freqId,
                                      "refillFreqId"  :refillfrequency,
                                      "otherFreq"            : frequencyOther,
                                      "refillFrequencyOther" : refillFrequencyOther
                                      }]);	
	return bodyContent;
};



mHealth.modelmapper.MedicationPostArchiveMapper=function(enddate,partMedId,reasonId ){
	var bodyContent = JSON.stringify([{
                                      "enddate" :enddate,
                                      "partMedId" : partMedId,
                                      "discontinueReasonId" : reasonId
                                      }]);	
	return bodyContent;
};


