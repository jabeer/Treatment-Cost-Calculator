mHealth.mobiscrollutil = {

	mobiScollDateTime : function(id) {
		$(id).scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios',
			beforeShow : function(input, inst) {
				mHealth.util.hideTabBar();
			},
			onClose : function(valueText, inst) {
				mHealth.util.showTabBar();
			}
		});

	},
	
	mobiScollDate : function(id) {
		$(id).scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'date',
			theme : 'ios',
			beforeShow : function(input, inst) {
				mHealth.util.hideTabBar();
			},
			onClose : function(valueText, inst) {
				mHealth.util.showTabBar();
			}
		});

	},
	
	

	mobiScollDateForMedication : function(id) {
		$(id).scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'date',
			theme : 'ios',
			beforeShow : function(input, inst) {
				mHealth.util.hideTabBar();
			},
			onClose : function(valueText, inst) {
				mHealth.util.showTabBar();
			},
			onSelect : function(valueText, inst) {
				
				var todayDt = new Date();
				
				var monthDiff=mHealth.util.monthDiff(todayDt,inst.getDate())+1;
				if(monthDiff>6)
					{
					     mHealth.util.id=id;
					     mHealth.util.customAlert(mHealth.Medication.monthValidation, mHealth.util.showMobPicker);
					}
				
				
			}
		});

	}
}