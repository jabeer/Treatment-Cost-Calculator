mHealth.models.MedicalDevicesModel = Spine.Model.sub();
mHealth.models.MedicalDevicesModel.configure('MedicalDevicesModel','medicalDeviceId', 'sku', 'description', 'createTimestamp', 'lastUpdateTimestamp', 'createdByUser', 'lastUpdatedByUser');
