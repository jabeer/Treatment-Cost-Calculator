mHealth.models.FeatureGroupModel=Spine.Model.sub();
mHealth.models.FeatureGroupModel.configure("FeatureGroupModel","groupId","feature");

