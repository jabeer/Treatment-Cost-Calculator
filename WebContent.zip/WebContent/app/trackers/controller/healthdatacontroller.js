mHealth.controllers.HealthDataController = Spine.Controller
		.sub({
			healthDataTracker : '',
			trackerData : '',
			validForm : false,
			healthDataServiceCount : 0,
			el : 'body',
			service : mHealth.util.RemoteServiceProxy.getInstance(),
			events : {
				'click #viewJournal' : 'viewJournal',
				'click #viewNewEntry' : 'viewNewEntry',
				'pagebeforeshow #show_tracker_view' : 'showTracker',
				'pagebeforeshow #show_tracker_track' : 'newEntryTracker',
				'pageshow #show_tracker_track' : 'preventFormSubmit',
				'pageshow #show_journal' : 'addScroll',
				'pagebeforehide #show_journal' : 'removeScroll',
				'click #track_save' : 'newEntrySave',
				'click .tracker' : 'setTrackerType',
				'pagebeforeshow #show_journal' : 'showJournal',
				'click #showTrackerPage' : 'setGlucoseTracker',
				'click #track' : 'setChoPage',
				'click #detailCholesterolBack' : 'setCholesterolTracker',
				'click #back' : 'setBackPage',
				'click #save_add_another' : 'newEntrySaveADDAnother',
				'pagebeforeshow #show_tracker' : 'showTrackers',
				'pageshow #show_tracker' : 'viewTabbar',
				'pagebeforeshow #exams' : 'showExamsList',
				'click #selectADateTime' : 'showDateTimePicker',
				'swiperight #show_tracker_view' : 'loadTrackerOnSwipeRight',
				'swipeleft #show_tracker_view' : 'loadTrackerOnSwipeLeft',
				'swipeleft #show_tracker_track' : 'swipeToGraph',
				'swiperight #show_journal' : 'swipeToGraph',
				'change #comments' : 'onCommentsChange',

			},

			/**
			 * Name : onCommentsChange Purpose : pagebefore show processing of
			 * the onCommentsChange Params : -- Returns : --
			 */
			onCommentsChange : function(event) {

				mHealth.util.logMessage('Inside the onCommentsChange Select');

				var comments = $('select#comments option:selected').val();
				if (comments == mHealth.TrackerNewEntry.dropdownOption1) {
					$('div[id=dateDiv]').hide('slow');
					$('div[id=valuesDiv]').hide('slow');
					var trackerId= this.setTrackerId();
					if (trackerId != 'Weight & BMI'	|| trackerId != 'Blood Glucose'	|| trackerId == 'Foot Sores"') {
						$('div[id=saveaddnewDiv]').hide();
					}
					
				}
				else
					{
					$('div[id=dateDiv]').show('slow');
					$('div[id=saveaddnewDiv]').show();
					if (comments == mHealth.TrackerNewEntry.dropdownOption2){
						 $('div[id=valuesDiv]').hide('slow');
					}
					else
						{
						$('div[id=valuesDiv]').show('slow');
						}
					}
					
				
					

			},

			

			swipeToGraph : function() {
				if (!this.isTrackerDirty()) {
					if (this.healthDataTracker == "Cholesterol") {
						$.mobile.changePage('detailscholesterol.html');
					} else {
						mHealth.GraphControllerObject.viewGraph();
					}
				} else {
					mHealth.util
							.customPromptForMessage(
									mHealth.Message.swipePrompt,
									function() {
										if (this.healthDataTracker == "Cholesterol") {
											$.mobile
													.changePage('detailscholesterol.html');
										} else {
											mHealth.GraphControllerObject
													.viewGraph();
										}
									}, function() {
									});
				}
			},

			newTrackerOnSwipeLeft : function() {
				this.setPreviousHealthData();
				$.mobile.changePage("../../rootview/view/transaction.html");
				$.mobile
						.changePage("../../trackers/view/showtrackertrack.html");
			},

			newTrackerOnSwipeRight : function() {

				this.setNextHealthData();
				$.mobile.changePage("../../rootview/view/transaction.html");
				$.mobile
						.changePage("../../trackers/view/showtrackertrack.html");
				// $('#show_tracker_track').trigger('pageshow');
			},

			TrackersUnsaved : function(form) {
				mHealth.util.logMessage('On Trackers Unsaved Form');
				var e = form.elements;
				var type = document.getElementById('tracker_id').value;
				if (type == 'Cholesterol' || type == 'A1c'
						|| type == 'Foot Exam - Provider'
						|| type == 'Microalbumin'
						|| type == 'Dilated Retinal Exam') {
					var comments = $('select#comments option:selected').val();
					if (comments != '') {
						return true;
					}
					if (comments == mHealth.TrackerNewEntry.dropdownOption1) {

						// 'I have never had the test completed')
						return true;
					} else if (comments == mHealth.TrackerNewEntry.dropdownOption2
							&& $('#selectDate').val() != "" && !isAndroid) {
						return true;
					} else if (comments == mHealth.TrackerNewEntry.dropdownOption2
							&& $('#selectADateTime').val() != "" && isAndroid) {
						return true;
					} else if ($('#selectDate').val() != "" && !isAndroid) {
						return true;
					} else if ($('#selectADateTime').val() != "" && isAndroid) {
						return true;
					}

					if (comments.length == 0) {
						return false;
					}
				}
				if (type == 'Cholesterol') {
					if ($('#value_LDL').val() != ""
							|| $('#value_HDL').val() != ""
							|| $('#value_Tri').val() != ""
							|| $('#value_Cholesterol').val() != "") {
						return true;
					}
					return false;
				} else {
					if (isAndroid) {
						if ($('#selectADateTime').val() != "") {
							return true;
						}
					} else if ($('#selectDate').val() != "") {
						return true;
					}

					for ( var elem, i = 0; (elem = e[i]); i++) {
						if (elem.type == 'text' || elem.type == 'tel'
								|| elem.type == 'number') {
							if (elem.value != '') {
								return true;
							}
						}
					}// for each elem
				}
				return false;
			},

			isTrackerDirty : function() {
				if ($('.ui-page-active').attr('id') == "show_tracker_track") {
					var currentDiv = this.getCurrentContentDiv();
					if (currentDiv.length > 0) {
						var currentForm = $('form', currentDiv);
						return this.TrackersUnsaved(currentForm.get(0));
					}
				}

			},

			setPreviousHealthData : function() {
				var trackerFeature = mHealth.models.FeatureGroupModel
						.findByAttribute('groupId', 'trackers');
				var trackersData = [];
				var examsList = [];
				// var trackersData = trackerFeature.feature;
				if (trackerFeature.feature != undefined
						|| trackerFeature.feature != null) {
					for ( var i = 0; i < trackerFeature.feature.length; i++) {
						if (trackerFeature.feature[i].id
								.match(/tracker-exam-.*/)) {
							examsList.push(trackerFeature.feature[i]);
						} else {
							trackersData.push(trackerFeature.feature[i])
						}
					}
				}
				var trackersVal = mHealth.util.getSortData(trackersData);
				var examsList = mHealth.util.getSortData(examsList);
				mHealth.util.examsList = examsList;
				var healthData = this.healthDataTracker;
				var newHealthData = this.healthDataTracker;
				var lastHealthData = examsList[examsList.length - 1].id;
				var isExamsTracker = true;

				$
						.each(
								trackersVal,
								function(index, value) {
									if (mHealth.TrackersFeaturesText[value.id] === healthData) {
										if (index != 0) {
											newHealthData = mHealth.TrackersFeaturesText[trackersVal[index - 1].id];
											isExamsTracker == false;
										} else {
											newHealthData = mHealth.TrackersFeaturesText[lastHealthData];
											isExamsTracker == false;
										}
									}
								});

				if (isExamsTracker == true) {
					$
							.each(
									examsList,
									function(index, value) {
										if (mHealth.TrackersFeaturesText[value.id] === healthData) {
											if (index != 0) {
												newHealthData = mHealth.TrackersFeaturesText[examsList[index - 1].id];
											} else {
												newHealthData = mHealth.TrackersFeaturesText[trackersVal[trackersVal.length - 1].id];
											}
										}

									});
				}

				this.healthDataTracker = newHealthData;
				mHealth.GraphControllerObject.healthDataTracker = newHealthData;
			},

			setNextHealthData : function() {
				var trackerFeature = mHealth.models.FeatureGroupModel
						.findByAttribute('groupId', 'trackers');
				var trackersData = [];
				var examsList = [];
				// var trackersData = trackerFeature.feature;
				if (trackerFeature.feature != undefined
						|| trackerFeature.feature != null) {
					for ( var i = 0; i < trackerFeature.feature.length; i++) {
						if (trackerFeature.feature[i].id
								.match(/tracker-exam-.*/)) {
							examsList.push(trackerFeature.feature[i]);
						} else {
							trackersData.push(trackerFeature.feature[i])
						}
					}
				}
				var trackersVal = mHealth.util.getSortData(trackersData);
				var examsList = mHealth.util.getSortData(examsList);
				mHealth.util.examsList = examsList;
				var setType = false;
				var healthData = this.healthDataTracker;
				var newHealthData = this.healthDataTracker;
				var firstHealthData = trackersVal[0].id;
				var isExamsTracker = true;

				$
						.each(
								trackersVal,
								function(index, value) {

									if (setType == true) {
										newHealthData = mHealth.TrackersFeaturesText[value.id];
										setType = false;
									}

									if (mHealth.TrackersFeaturesText[value.id] === healthData) {

										isExamsTracker = false;
										if ((index + 1) == trackersVal.length) {
											newHealthData = mHealth.TrackersFeaturesText[examsList[0].id];
										}
										setType = true;
									}

								});

				if (isExamsTracker == true) {
					$
							.each(
									examsList,
									function(index, value) {
										if (setType == true) {
											newHealthData = mHealth.TrackersFeaturesText[value.id];
											setType = false;
										}

										if (mHealth.TrackersFeaturesText[value.id] === healthData) {
											if ((index + 1) == examsList.length) {
												newHealthData = mHealth.TrackersFeaturesText[firstHealthData];
											}
											setType = true;
										}

									});
				}

				this.healthDataTracker = newHealthData;
				mHealth.GraphControllerObject.healthDataTracker = newHealthData;
			},

			loadTrackerOnSwipeRight : function() {
				// TODO : need to do the code refactoring

				this.setNextHealthData();
				this.loadTrackerDataForTracker();
				$.mobile.changePage("../../rootview/view/transaction.html");
				$('#show_tracker_view').trigger('pagebeforeshow');
			},

			loadTrackerOnSwipeLeft : function() {
				// TODO : need to do the code refactoring
				this.setPreviousHealthData();
				this.loadTrackerDataForTracker();
				$.mobile.changePage("../../rootview/view/transaction.html");
				$('#show_tracker_view').trigger('pagebeforeshow');
			},

			showDateTimePicker : function() {
				if (isAndroid) {
					if ($('#tracker_id').val() == 'Weight & BMI'
							|| $('#tracker_id').val() == 'Blood Pressure'
							|| $('#tracker_id').val() == 'Blood Glucose') {
						mHealth.util.logMessage('inside showDateTimePicker function for multiple healthdata '	+ $('#selectADateTime').val());
						nativeCommunication	.callNativeMethod("picker://DateTime?id=selectADateTime&value="	+ $('#selectADateTime').val());
					} else {
						mHealth.util.logMessage('inside showDateTimePicker function for single healthdata');
						showDatePicker('selectADateTime','#selectADateTime','tracker');
					}
				}
			},

			/**
			 * Name : viewTabbar Purpose : Method to viewTabbar Params : --
			 * Return : --
			 */
			viewTabbar : function() {
				mHealth.util
						.logMessage('inside showTabbar healthdatacontroller');
				if (isAndroid) {
					Android.showTab();
				} else if (isIOS) {
					mHealth.util.unloadChart();
					mHealth.util.showTabBar();
				}
			},

			preventFormSubmit : function() {
				mHealth.util.logMessage('Prevent Form Submit');
				if (isAndroid) {
					$('#tracker_newEntry').bind('submit', function(e) {
						e.preventDefault();
						e.stopImmediatePropagation();
					});
				}
			},

			removeScroll : function() {
				mHealth.util.logMessage('Remove scroll called');
				$(document).unbind('touchmove', mHealth.util.prevDefault());
			},
			addScroll : function() {
				var windowHeight = window.innerHeight;
				var journalHeight = windowHeight - 44;
				$('#journalScroll').css({
					'height' : journalHeight
				});
				mHealth.util.journalScroll = new iScroll('journalScroll', {
					bounce : false,
					checkDOMChanges : false
				});
				$(document).bind('touchmove', mHealth.util.prevDefault());
			},
			/**
			 * Name: setChoPage Purpose: Sets Cholesterol type Params: --
			 * Returns: doesn't return
			 */
			setChoPage : function() {
				mHealth.util.logMessage('on SetChoPage');
				if (this.healthDataTracker == 'LDL'
						|| this.healthDataTracker == 'HDL'
						|| this.healthDataTracker == 'TotalCholesterol'
						|| this.healthDataTracker == 'Triglycerides') {
					this.healthDataTracker = "Cholesterol";
					mHealth.GraphControllerObject.healthDataTracker = "Cholesterol";
				}
				this.viewNewEntry();
				this.unloadChart();
			},
			/**
			 * Name: setCholesterolTracker Purpose: Sets Cholesterol as
			 * healthdatatracker type when getting back from detail cholesterol
			 * page Params: -- Returns: doesn't return
			 */
			setCholesterolTracker : function() {
				mHealth.util.logMessage('Set Cholesterol Tracker Function');
				this.healthDataTracker = "Cholesterol";
				mHealth.GraphControllerObject.healthDataTracker = "Cholesterol";
			},
			/**
			 * Name: newEntrySaveADDAnother Purpose: Saves new tracker entry
			 * Params: No params Returns: Doesn't return
			 */
			newEntrySaveADDAnother : function() {
				mHealth.util
						.logMessage('Clicked on save and Add another button');
				if (mHealth.SettingsAbout.networkStatus != 'false') {
					var currentDiv = this.getCurrentContentDiv();
					if (currentDiv.length > 0) {
						var currentForm = $('form', currentDiv);
						if (this.validateForm(currentForm.get(0))) {
							this.validForm = true;
						} else {
							this.validForm = false;
							mHealth.util.customAlert(
									mHealth.Validation.generic, '');
						}
					}

					if (this.validForm) {
						if (!(this.validateHealthData())) {
							return false;
						}
						this.clearForm(currentForm.get(0));
						$('#comments').change();
					}
				} else {
					mHealth.util.customAlert(
							mHealth.SyncProcessController.msgConnectionError,
							'');
				}
			},
			/**
			 * Name: clearForm Purpose: form fields are validated here Params:
			 * html form object Returns: returns boolean value denoting the
			 * valid form
			 */
			clearForm : function(form) {
				mHealth.util.logMessage('Cleared the Form');
				$('#save_add_another').removeClass('ui-btn-active');
				$('#tracker_newEntry')[0].reset();
				$('select').selectmenu('refresh');
			},
			/**
			 * Name: setBackPage Purpose: Sets Cholesterol type Params: event
			 * object is passed implicitly. No params are passed explicitly
			 * Returns: doesn't return
			 */
			setBackPage : function() {
				mHealth.util
						.logMessage('Setting the Back Page for the Chelosterol');
				if (this.healthDataTracker != 'LDL'
						&& this.healthDataTracker != 'HDL'
						&& this.healthDataTracker != 'TotalCholesterol'
						&& this.healthDataTracker != 'Triglycerides')
					$.mobile.changePage("detailtracker.html");
				else
					$.mobile.changePage("detailscholesterol.html");
				this.unloadChart();
			},

			/**
			 * Name: loadTrackerDataForTracker Purpose: Loads health data based
			 * on the tracker type. Params: event object is passed implicitly.
			 * No params are passed explicitly Returns: doesn't return
			 */
			loadTrackerDataForTracker : function(tracker) {
				mHealth.util.logMessage('Load the tracker data');
				this.healthDataServiceCount = 0;
				mHealth.util.showMask();
				var count = mHealth.models.HealthDataModel.count();
				var trackerURL = '';

				if (this.healthDataTracker == 'Blood Glucose') {
					trackerURL = 'Bloodglucose';
				} else if (this.healthDataTracker == 'Dilated Retinal Exam') {
					trackerURL = 'RetinalExam';
				} else if (this.healthDataTracker == 'Foot Sores') {
					trackerURL = 'FootSores';
				} else if (this.healthDataTracker == 'Foot Exam - Provider') {
					trackerURL = 'FootExam';
				} else if (this.healthDataTracker == 'Microalbumin') {
					trackerURL = 'MAU';
				} else if (this.healthDataTracker == 'A1c') {
					trackerURL = 'A1c';
				} else if (this.healthDataTracker == 'Weight & BMI') {
					trackerURL = 'Weight';
					URL = mHealth.env.healthdata_url + trackerURL + "?maxdays="
							+ mHealth.TrackerGraph.maxDays;
					this.proxy(this.service.getResponse(URL, this
							.proxy(this.setHealthData), null, false));

					// will execute at the end
					trackerURL = 'BMI';
				} else if (this.healthDataTracker == 'Blood Pressure') {
					trackerURL = 'BPS';
				} else if (this.healthDataTracker == 'Cholesterol') {
					trackerURL = 'LDL';
					URL = mHealth.env.healthdata_url + trackerURL + "?maxdays="
							+ mHealth.TrackerGraph.maxDays;
					this.proxy(this.service.getResponse(URL, this
							.proxy(this.setHealthData), null, false));

					trackerURL = 'HDL';
					URL = mHealth.env.healthdata_url + trackerURL + "?maxdays="
							+ mHealth.TrackerGraph.maxDays;
					this.proxy(this.service.getResponse(URL, this
							.proxy(this.setHealthData), null, false));

					trackerURL = 'TotalCholesterol';
					URL = mHealth.env.healthdata_url + trackerURL + "?maxdays="
							+ mHealth.TrackerGraph.maxDays;
					this.proxy(this.service.getResponse(URL, this
							.proxy(this.setHealthData), null, false));

					// will execute at the end
					trackerURL = 'Triglycerides';
				} else if (this.healthDataTracker == 'Exams') {
					mHealth.util.hideMask();
				}

				if (trackerURL != '') {
					var URL = mHealth.env.healthdata_url + trackerURL
							+ "?maxdays=" + mHealth.TrackerGraph.maxDays;
					this.healthDataServiceCount = 12;
					// this.healthDataFlag = true;
					this.proxy(this.service.getResponse(URL, this
							.proxy(this.setHealthData), this
							.proxy(this.setHealthDataFailure), false));
				}

			},

			/**
			 * Name: unloadChart Purpose: Params: Returns:
			 */
			unloadChart : function(e) {
				mHealth.util.logMessage('Unload the Chart');
				mHealth.util.unloadChart();
			},
			/**
			 * Name: setTrackerType Purpose: Sets Tracker type Params: event
			 * object is passed implicitly. No params are passed explicitly
			 * Returns: doesn't return
			 */
			setTrackerType : function(e) {
				mHealth.util.logMessage('Set the tracker Type');
				this.healthDataTracker = $(e.target).parents(".tracker").attr(
						'name');
				mHealth.GraphControllerObject.healthDataTracker = this.healthDataTracker;
				this.loadTrackerDataForTracker();
			},

			/**
			 * Name: showJournal Purpose: Renders the showjournal.html page
			 * content Params: No params Returns: Doesn't return
			 */
			showJournal : function() {
				mHealth.util.logMessage('On  Show Journal Page');
				var trackerType = {
					"name" : this.healthDataTracker
				};
				$('#journal_header_content').html(
						_.template($('#journal_header_template').html(), {
							trackerType : trackerType
						}));
				$('#journal_content').html(
						_.template($('#journal_list').html(), {
							trackerData : this.trackerData,
							trackerType : trackerType
						}));
				$('#journal_header_content').trigger('create');
				$('#journal_content').trigger('create');
				// mHealth.util.hideMask();
			},
			/**
			 * Name: showTracker Purpose: renders the showtracker.html page
			 * Params: No params required Returns: Doesn't return
			 */
			showTracker : function() {
				mHealth.util.logMessage('On  Show Tracker Page');

				var trackerType = {
					"name" : this.healthDataTracker
				};
				$('#trackviewcontent').html(
						_.template($('#trackerviewtemplate').html(), {
							trackerType : trackerType
						}));
				$('#headercontent').html(
						_.template($('#headertemplate').html(), {
							trackerType : trackerType
						}));
				$('#headercontent').trigger('create');
				$('#trackviewcontent').trigger('create');

			},
			/**
			 * Name: newEntryTracker Purpose: renders the showtrackertrack.html
			 * page Params: None Returns:Doesn't return
			 */
			newEntryTracker : function() {
				// healthDataTracker has to change to class level.
				mHealth.util.logMessage('On  new Entry Tracker Page');
				var trackerType = {
					"name" : this.healthDataTracker
				};
				$('#showtrackertrackcontent').html(
						_.template($('#showtrackertracktemplate').html(), {
							trackerType : trackerType
						}));
				$('#showtrackertrackcontent').trigger('create');
			},
			/**
			 * Name: newHDataObject Purpose: Creates new health data object to
			 * be saved Params: measurement date, collected date and value.
			 * These are set in json object that is created. Returns: returns a
			 * formatted object to be passed as a param in the postRequest
			 * service call
			 */
			newHDataObject : function(value, type, groupId) {
				mHealth.util
						.logMessage('Setting the value for the newHDataObject');
				var tgroupId = "";
				if (groupId != undefined && groupId != null) {
					tgroupId = groupId;
				}
				var comments = "";
				if (this.healthDataTracker != 'Blood Glucose'
						&& this.healthDataTracker != 'Weight & BMI') {
					comments = $('#comments').val();
				}
				// if(comments == mHealth.TrackerNewEntry.recordComments) {
				// comments = "";
				// }
				var measurementDate = this.getMeasurementDate();
				var measurementUnit = this.getMeasurementUnits();
				return mHealth.recommendation.HealthDataTypeMapper(
						measurementDate, comments, value, type,
						measurementUnit, tgroupId)
			},
			getMeasurementUnits : function() {
				mHealth.util.logMessage('get the Measurement Units');
				var measurementUnit;
				// if(mHealth.util.selUnits == undefined){
				if (this.healthDataTracker == 'Weight & BMI') {
					measurementUnit = 'lb';
				}
				if (this.healthDataTracker == 'Height') {
					measurementUnit = 'ft-inch';
				}
				if (this.healthDataTracker == 'Blood Glucose'
						|| this.healthDataTracker == 'Cholestrol') {
					measurementUnit = 'mg/dl';
				}
				return measurementUnit;
			},
			/**
			 * Name: getMeasurementDate Purpose: formats the measurement date to
			 * be passed as a parameter for health data object Params: No params
			 * Returns: returns formatted date object
			 */
			getMeasurementDate : function() {
				mHealth.util.logMessage('get the Measurement Date');
				if (isAndroid) {
					var dateSelected = $('#selectADateTime').val();
					mHealth.util.logMessage('on Andorid' + dateSelected);
				} else {
					var dateSelected = $('#selectDate').val();
				}
				var newDate = new Date();
				var dateObject = new Date(newDate.getFullYear(), newDate
						.getMonth(), newDate.getDate());

				if (dateSelected != "")
					mHealth.util.logMessage('on Andorid' + dateSelected);
				dateObject = new Date(dateSelected.substr(6, 4), (dateSelected
						.substr(0, 2) - 1), dateSelected.substr(3, 2));
				mHealth.util.logMessage('on Andorid' + dateObject);
				if (this.healthDataTracker == 'Blood Pressure'
						|| this.healthDataTracker == 'Blood Glucose'
						|| this.healthDataTracker == 'Weight & BMI') {
					if (dateSelected != "") {
						mHealth.util
								.logMessage('on Andorid if dateselected is empty'
										+ dateObject);
						/*
						 * var hour = dateSelected.substr(11, 2); hour =
						 * parseInt(hour, 10); if(dateSelected.substr(17, 2) ==
						 * "PM") { if(hour != 12) hour = hour + 12; } else {
						 * if(hour == 12) hour = 0; } utcSec =
						 * Date.UTC(dateSelected.substr(6, 4),
						 * (dateSelected.substr(0, 2) - 1),
						 * dateSelected.substr(3, 2), hour,
						 * dateSelected.substr(14, 2)); dateObject =
						 * mHealth.util.getDateFormat(dateSelected);
						 */
						return mHealth.util.getDateFormat(dateSelected);
					} else {
						mHealth.util.logMessage('on Andorid else' + dateObject);
						utcSec = Date.UTC(newDate.getFullYear(), newDate
								.getMonth(), newDate.getDate(), newDate
								.getHours(), newDate.getMinutes());
						dateObject = new Date(utcSec);
					}
				}
				return dateObject.format(mHealth.pegadateformat);
			},
			/**
			 * Name: getCurrentContentDiv Purpose: gets current div of the page
			 * Params: No params Returns: Doesn't return
			 */
			getCurrentContentDiv : function() {
				mHealth.util.logMessage('get the Current Content Div');
				var currentDiv = $.mobile.activePage

				if (currentDiv.length == 0) {
					currentDiv = $('body');
				}
				return currentDiv;
			},
			/**
			 * Name: validateForm Purpose: form fields are validated here
			 * Params: html form object Returns: returns boolean value denoting
			 * the valid form
			 */
			validateForm : function(form) {
				mHealth.util.logMessage('On validate Form');
				var e = form.elements;
				var type = document.getElementById('tracker_id').value;
				if (type == 'Cholesterol' || type == 'A1c'
						|| type == 'Foot Exam - Provider'
						|| type == 'Microalbumin'
						|| type == 'Dilated Retinal Exam') {
					var comments = $('select#comments option:selected').val();
					if (comments == mHealth.TrackerNewEntry.dropdownOption1) {
						// 'I have never had the test completed' {
						return true;
					} else if (comments == mHealth.TrackerNewEntry.dropdownOption2
							&& $('#selectDate').val() != "") {
						return true;
					}
					if (comments.length == 0) {
						return false;
					}
				}
				if (type == 'Cholesterol') {
					for ( var elem, i = 0; (elem = e[i]); i++) {
						if (elem.type == 'number') {
							if (elem.value != ''
									&& $('#selectDate').val() != "") {
								return true;
							}
						}
					}// for each elem
					return false;
				} else {
					for ( var elem, i = 0; (elem = e[i]); i++) {
						if (elem.type == 'text' || elem.type == 'tel'
								|| elem.type == 'number') {
							if (elem.value == '') {
								return false;
							}
						}
					}// for each elem
				}
				return true;
			},
			/**
			 * Name: newEntrySave Purpose: Saves new tracker entry Params: No
			 * params Returns: Doesn't return
			 */
			newEntrySave : function() {
				mHealth.util.logMessage('On new Entry Save Function');
				if (mHealth.SettingsAbout.networkStatus != 'false') {
					var currentDiv = this.getCurrentContentDiv();
					if (currentDiv.length > 0) {
						var currentForm = $('form', currentDiv);
						if (this.validateForm(currentForm.get(0))) {
							this.validForm = true;
						} else {
							this.validForm = false;
							mHealth.util.customAlert(
									mHealth.Validation.generic, '');
						}
					}
					if (this.validForm) {
						if (!(this.validateHealthData())) {
							return false;
						}
						if (this.healthDataTracker != 'LDL'
								&& this.healthDataTracker != 'HDL'
								&& this.healthDataTracker != 'TotalCholesterol'
								&& this.healthDataTracker != 'Triglycerides') {
							$.mobile.changePage("detailtracker.html");
						} else {
							$.mobile.changePage("detailscholesterol.html");
						}
					}
				} else {
					mHealth.util.customAlert(
							mHealth.SyncProcessController.msgConnectionError,
							'');
				}
			},
			setTrackerId : function() {
				var trackerId = '';
				if (this.healthDataTracker == 'Blood Glucose') {
					trackerId = 'Bloodglucose';
				} else if (this.healthDataTracker == 'Dilated Retinal Exam') {
					trackerId = 'RetinalExam';
				} else if (this.healthDataTracker == 'Foot Sores') {
					trackerId = 'FootSores';
				} else if (this.healthDataTracker == 'Foot Exam - Provider') {
					trackerId = 'FootExam';
				} else if (this.healthDataTracker == 'Microalbumin') {
					trackerId = 'MAU';
				} else if (this.healthDataTracker == 'A1c') {
					trackerId = 'A1C';
				} else if (this.healthDataTracker == 'Weight & BMI') {
					trackerId = 'Weight';
				} else if (this.healthDataTracker == 'Blood Pressure') {
					trackerId = 'BPS';
				} else if (this.healthDataTracker == 'Cholesterol') {
					trackerId = 'Cholesterol';
				}
				return trackerId;
			},
			/**
			 * Name: newEntrySave Purpose: Saves new tracker entry Params: No
			 * params Returns: Doesn't return
			 */
			validateHealthData : function() {
				mHealth.util.logMessage('On Validate the Health data');
				var healthDataResponse = [];
				var isCholExistForDay = false;
				var trackerId = this.setTrackerId();
				if (trackerId == "Cholesterol") {
					ldlResponse = this.getHealthTrackerData("LDL");
					hdlResponse = this.getHealthTrackerData("HDL");
					tryResponse = this.getHealthTrackerData("Triglycerides");
					tcResponse = this.getHealthTrackerData("TotalCholesterol");
					if (this.isExists(ldlResponse) === true
							|| this.isExists(hdlResponse) === true
							|| this.isExists(tryResponse) === true
							|| this.isExists(tcResponse) === true) {
						isCholExistForDay = true;
					}
				} else {
					healthDataResponse = this.getHealthTrackerData(trackerId);
				}

				if (this.isExists(healthDataResponse) === false
						&& !isCholExistForDay) {
					this.postHealthDataResponse();
					return true;
				} else {
					if (trackerId == "BPS" || trackerId == "Weight"
							|| trackerId == "Bloodglucose") {
						mHealth.util.customAlert(
								mHealth.TrackerNewEntry.existingDataTime, '');
					} else {
						mHealth.util.customAlert(
								mHealth.TrackerNewEntry.existingData, '');
					}
					return false;
				}
			},
			isExists : function(healthDataResponse) {
				mHealth.util
						.logMessage('On Data already exixts for the mentioned date');
				var formattedDateObject = this.getMeasurementDate();
				var trackerId = this.setTrackerId();
				if (trackerId != "Cholesterol") {
					formattedDateObject = Date.UTC(formattedDateObject.substr(
							0, 4), formattedDateObject.substr(4, 2) - 1,
							formattedDateObject.substr(6, 2),
							formattedDateObject.substr(9, 2),
							formattedDateObject.substr(11, 2));
					formattedDateObject = new Date(formattedDateObject)
							.format(mHealth.pegadateformat);
				}
				var flag = false;
				if (trackerId == "BPS" || trackerId == "Weight"
						|| trackerId == "Bloodglucose"
						|| trackerId == "Cholesterol") {
					healthDataResponse.map(function(response) {
						if (response.measurementDate == formattedDateObject) {
							flag = true;
							return flag;
						}
					});
				} else {
					healthDataResponse
							.map(function(response) {
								if ((response.measurementDate).substr(0, 8) == formattedDateObject
										.substr(0, 8)) {
									flag = true;
									return flag;
								}
							});
				}
				return flag;
			},
			/**
			 * Name: postHealthDataResponse Purpose: success callback function
			 * for new entry tracker save Params: output from postRequest as
			 * implicit param Returns: Doesn't return
			 */
			postHealthDataResponse : function() {
				mHealth.util.logMessage('Post the Response to the server');
				var formattedDateObject = this.getMeasurementDate();
				var weightModifier = 1;
				var trackerId = this.setTrackerId();
				var hDataObject = null;
				var value = 0;
				var groupId = trackerId + "-"
						+ mHealth.util.getCurrentDateTime();
				if (trackerId == 'RetinalExam' || trackerId == 'FootExam'
						|| trackerId == 'MAU') {
					if (isAndroid) {// selectADateTime
						value = $('#selectADateTime').val();
					} else {
						value = $('#selectDate').val();// this.getMeasurementDate();
					}
				} else if (trackerId == 'FootSores') {
					value = $('select#examOptn option:selected').val();
				} else if (trackerId == "Weight") {
					if (mHealth.util.selWeightUnits == 'Kg') {
						weightModifier = 2.205;
					}
					value = String(parseFloat($('#value_Weight').val(), 10)
							* weightModifier);
					var bmiHDataObject = this.newHDataObject($('#value_BMI')
							.val(), 'BMI', groupId);

					var localDataJson = JSON.parse(bmiHDataObject);
					var localDataObject = JSON.stringify(localDataJson,
							mHealth.util.convertToLocalTime);
					mHealth.models.HealthDataModel
							.customFromJSON(localDataObject);
					this.service.postRequest(
							(mHealth.env.healthdata_url + "BMI"),
							bmiHDataObject, null, null, false);
				} else if (trackerId == "BPS") {
					// SYSTOIC and DIASTOLIC must be posted in single service
					// call to avoid a race condition on the server
					groupId = "BP-" + mHealth.util.getCurrentDateTime();

					var comments = $('#comments').val();
					var measurementDate = this.getMeasurementDate();
					var measurementUnit = this.getMeasurementUnits();

					var bpHDataObjectArray = mHealth.recommendation
							.BPHealthDataTypeMapper(measurementDate, comments,
									$('#value_SYS').val(), $('#value_DIA')
											.val(), measurementUnit, groupId);
					// local data model population
					var localDataJson = JSON.parse(bpHDataObjectArray);
					var localDataObject = JSON.stringify(localDataJson,
							mHealth.util.convertToLocalTime);
					mHealth.models.HealthDataModel
							.customFromJSON(localDataObject);

					// Using a new gerneric BP for DataPower script to key on
					this.service.postRequest(
							(mHealth.env.healthdata_url + "BP"),
							bpHDataObjectArray, null, null, false);

				} else if (trackerId == "Cholesterol") {
					var ldlValue = $('#value_LDL').val();
					var hdlValue = $('#value_HDL').val();
					var triValue = $('#value_Tri').val();
					var choValue = $('#value_Cholesterol').val();
					if ($('select#comments option:selected').val() == mHealth.TrackerNewEntry.dropdownOption1) {
						value = "Never tested";
					} else if ($('select#comments option:selected').val() == mHealth.TrackerNewEntry.dropdownOption2) {
						value = "Tested Result Unknown";
					}
					if (value != 0) {
						ldlValue = value;
						hdlValue = value;
						triValue = value;
						choValue = value;
					}
					var ldlHDataObject = this.newHDataObject(ldlValue, 'LDL',
							groupId);
					var hdlHDataObject = this.newHDataObject(hdlValue, 'HDL',
							groupId);
					var triHDataObject = this.newHDataObject(triValue,
							'Triglycerides', groupId);
					var choHDataObject = this.newHDataObject(choValue,
							'TotalCholesterol', groupId);
					if (value == "Never tested") {
						ldlHDataObject = this
								.setMeasurementDate(ldlHDataObject);
						hdlHDataObject = this
								.setMeasurementDate(hdlHDataObject);
						triHDataObject = this
								.setMeasurementDate(triHDataObject);
						choHDataObject = this
								.setMeasurementDate(choHDataObject);
					}
					mHealth.models.HealthDataModel
							.customFromJSON(ldlHDataObject);
					mHealth.models.HealthDataModel
							.customFromJSON(hdlHDataObject);
					mHealth.models.HealthDataModel
							.customFromJSON(triHDataObject);
					mHealth.models.HealthDataModel
							.customFromJSON(choHDataObject);
					if (ldlValue != '') {
						this.service.postRequest(
								(mHealth.env.healthdata_url + "LDL"),
								ldlHDataObject, null, null, false);
					}
					if (hdlValue != '') {
						this.service.postRequest(
								(mHealth.env.healthdata_url + "HDL"),
								hdlHDataObject, null, null, false);
					}
					if (triValue != '') {
						this.service.postRequest(
								(mHealth.env.healthdata_url + "Triglycerides"),
								triHDataObject, null, null, false);
					}
					if (choValue != '') {
						this.service
								.postRequest(
										(mHealth.env.healthdata_url + "TotalCholesterol"),
										choHDataObject, null, null, false);
					}
				} else {
					value = $("#value_" + trackerId).val();
				}

				// Cholesterol and Blood Pressure already cared for above
				if (trackerId != "Cholesterol" && trackerId != "BPS") {
					if (trackerId == 'RetinalExam' || trackerId == 'FootExam'
							|| trackerId == 'MAU' || trackerId == 'A1C') {
						if ($('select#comments option:selected').val() == mHealth.TrackerNewEntry.dropdownOption1) {
							value = "Never tested";
						} else if (trackerId == 'A1C'
								&& $('select#comments option:selected').val() == mHealth.TrackerNewEntry.dropdownOption2) {
							value = "Tested Result Unknown";
						}
					}
					hDataObject = this
							.newHDataObject(value, trackerId, groupId);
					if (value == "Never tested") {
						hDataObject = this.setMeasurementDate(hDataObject);
						mHealth.models.HealthDataModel
								.customFromJSON(hDataObject);
					} else {
						hLocalDataObject = hDataObject;
						if (trackerId == "Weight"
								|| trackerId == "Bloodglucose") {
							var localDataJson = JSON.parse(hDataObject);
							hLocalDataObject = JSON.stringify(localDataJson,
									mHealth.util.convertToLocalTime);
						}
						mHealth.models.HealthDataModel
								.customFromJSON(hLocalDataObject);
					}
					this.service.postRequest(
							(mHealth.env.healthdata_url + trackerId),
							hDataObject, null, null, false);
				}
			},

			/**
			 * Name: setMeasurementDate Purpose: sets measurement date and
			 * collected date of json object to null. Params: json string
			 * Returns: json string with updated measurement date and collected
			 * date
			 */
			setMeasurementDate : function(hDataObject) {
				mHealth.util.logMessage('Set the Measurement date');
				var tempObject = JSON.parse(hDataObject)[0];
				tempObject.measurementDate = null;
				tempObject.collectedDate = null;
				return JSON.stringify([ tempObject ]);
			},

			/**
			 * Name: viewJournal Purpose: Calls a getResponse service call for
			 * the very first time, calls getJournalData otherwise. Params: No
			 * params Returns: Doesn't return
			 */
			viewJournal : function() {
				mHealth.util.logMessage('View Journal');
				mHealth.GraphControllerObject.graphDataFlag = false;
				this.healthDataServiceCount = 0;
				// this.loadTrackerDataForTracker();
				this.getJournalData();

			},
			/**
			 * Name: getJournalDataSuccess Purpose: Service call success
			 * callback function. Calls getJournalData that will eventually set
			 * the data for rendering journal data and hides mask. Params: No
			 * params Returns: Doesn't return
			 */
			getJournalDataSuccess : function(output) {
				mHealth.util.logMessage('On Journal Service Success');
				this.getJournalData();
				mHealth.util.hideMask();
			},
			/**
			 * Name: getJournalDataFailure Purpose: Service call failure
			 * callback function. Calls getJournalData that will eventually set
			 * the data for rendering journal data and hides mask. Params: No
			 * params Returns: Doesn't return
			 */
			getJournalDataFailure : function() {
				mHealth.util.logMessage('On Journal Service Failure');
				this.getJournalData();
				mHealth.util.hideMask();
			},
			/**
			 * Name: getJournalData Purpose: gets the Journal Data using
			 * getResponse service call. Called on view my journal click.
			 * Params: No params Returns: Doesn't return
			 */
			getJournalData : function() {
				// this.unloadChart();
				mHealth.util.logMessage('Get the Journal Service Data');
				var hasMultiValue = false;
				var healthDataResponse = [];
				var trackerId = this.setTrackerId();
				var subHealthDataTypes = [];

				if (this.healthDataTracker == "Blood Pressure") {
					hasMultiValue = true;
					subHealthDataTypes = [ 'BPS', 'BPD' ];
				} else if (this.healthDataTracker == "Cholesterol") {

					hasMultiValue = true;
					subHealthDataTypes = [ 'LDL', 'HDL', 'TotalCholesterol',
							'Triglycerides' ];
				} else if (this.healthDataTracker == "Weight & BMI") {
					hasMultiValue = true;
					subHealthDataTypes = [ 'Weight', 'BMI' ];
				}

				if (hasMultiValue === false) {
					healthDataResponse = this.getHealthTrackerData(trackerId);
				} else {
					for ( var i = 0; i < subHealthDataTypes.length; i++) {
						healthDataResponse = healthDataResponse.concat(this
								.getHealthTrackerData(subHealthDataTypes[i]));
					}
				}
				if (healthDataResponse != null) {
					sortedData = this.getSortedData(healthDataResponse,
							"measurementDate");
					// alert(sortedData + 'sortedDATa');
					this.trackerData = this.getFormattedData(sortedData);
					// console.log(this.trackerData);
					if (this.healthDataTracker != 'Blood Pressure'
							&& this.healthDataTracker != 'Blood Glucose'
							&& this.healthDataTracker != 'Weight & BMI') {
						var testNeverCompletedResponse = [];
						// if(hasMultiValue === false)
						// {
						testNeverCompletedResponse = this
								.getTestNeverCompletedData(trackerId);
						// }
						// else
						// {
						// for(var i = 0; i < subHealthDataTypes.length; i++) {
						// testNeverCompletedResponse =
						// testNeverCompletedResponse.concat(this.getTestNeverCompletedData(subHealthDataTypes[i]));
						// }
						// }
						var testSortedData = this.getSortedData(
								testNeverCompletedResponse, "insertDate")
						var len = testSortedData.length;
						var child;
						for ( var i = 0; i < len; i++) {
							child = new Object();
							child['measurementDate'] = testSortedData[i]['measurementDate'];
							child['insertDate'] = testSortedData[i]['insertDate'];
							child['value'] = testSortedData[i]['value'];
							child['comments'] = testSortedData[i]['comments'];
							this.trackerData[testSortedData[i].insertDate] = child;
						}
						// console.log(this.trackerData);
					}
					// alert(this.trackerData+' tracker Data');
					$.mobile.changePage("showjournal.html");

				} else {
					mHealth.util.showMask();
					if (hasMultiValue === false) {
						var URL = mHealth.env.healthdata_url + trackerId
								+ "?maxdays=45";
						this.service.getResponse(URL, this
								.proxy(this.processHealthData), this
								.proxy(this.getJournalFailure), true);
					} else {
						for ( var i = 0; i < subHealthDataTypes.length; i++) {
							var URL = mHealth.env.healthdata_url
									+ subHealthDataTypes[i] + "?maxdays=45";

							this.service
									.getResponse(URL, this
											.proxy(this.processHealthData),
											null, false);

						}
					}
				}
				return;
			},
			processHealthData : function(output) {

			},
			getHealthTrackerData : function(healthDataType) {
				mHealth.util.logMessage('Get the health Tracker Data');
				var healthDataResponse = [];
				var modelResponse = mHealth.models.HealthDataModel
						.findAllByAttribute("healthDataType", healthDataType);
				var prevYearDate = mHealth.util.getPrevYearDate();

				modelResponse.map(function(response) {
					if (response.measurementDate >= prevYearDate)
						healthDataResponse.push(response);
				});
				return healthDataResponse;
			},

			getTestNeverCompletedData : function(healthDataType) {
				if (healthDataType == 'Cholesterol') {
					healthDataType = 'LDL';
				}
				mHealth.util
						.logMessage('Get the health Tracker Data for Test Never Completed');
				var healthDataResponse = [];
				var modelResponse = mHealth.models.HealthDataModel
						.findAllByAttribute("healthDataType", healthDataType);
				var prevYearDate = mHealth.util.getPrevYearDate();
				// alert(modelResponse+ ' model response for '+healthDataType);
				modelResponse.map(function(response) {
					if (response.value == 'Never tested') {
						// alert(response);
						healthDataResponse.push(response);
					}
				});
				return healthDataResponse;
			},
			/**
			 * Name: setHealthData Purpose: Success Callback function for
			 * loadTrackerData. Loads the healthdata model with the service
			 * call's output. Params: -- Returns: --
			 */
			setHealthData : function(output) {
				mHealth.util.logMessage('Set the health Data');
				this.healthDataServiceCount++;
				if (output.responseText) {
					var response = JSON.parse(output.responseText);
					// var modelData = JSON.stringify(response);
					if (this.healthDataTracker == 'Blood Pressure'
							|| this.healthDataTracker == 'Blood Glucose'
							|| this.healthDataTracker == 'Weight & BMI') {

						var modelData = JSON.stringify(response,
								mHealth.util.convertToLocalTime);

						// var modelData = JSON.stringify(response,
						// this.convertToLocalTime);
					} else {
						var modelData = JSON.stringify(response);
					}

					mHealth.models.HealthDataModel.customFromJSON(modelData);
				}
				if ((this.healthDataServiceCount == 13)) { // 13 represents the
															// individual number
															// of health data
					// trackers and their corresponding service calls.

					mHealth.util.hideMask();
					mHealth.util.loadTrackerbar();
					$.mobile.changePage('../../trackers/view/detailtracker.html');
				}
			},

			/**
			 * Name: setHealthDataFailure Purpose: Failure Callback function for
			 * loadTrackerData. Alerts the user about network connection.
			 * Params: -- Returns: --
			 */
			setHealthDataFailure : function() {
				mHealth.util.logMessage('Set the health Data Failure');
				this.healthDataServiceCount++;

				if (this.healthDataServiceCount >= 13) {
					mHealth.util.customAlert(
							mHealth.Condition.informationErrMsg, function() {
								mHealth.util.hideMask();
								// $.mobile.changePage('../../trackers/view/detailtracker.html');
							});
				}
			},
			/**
			 * Name: getSortedData Purpose: sorts the health data based on
			 * measurement date. Params: health data to be sorted is passed as
			 * param Returns: returns the sorted health data
			 */
			getSortedData : function(healthData, sortingKey) {
				// alert(sortingKey);
				mHealth.util.logMessage('Set the Sorted Data');
				var keys = [];
				var sortedData = [];
				for ( var i in healthData) {
					keys[i] = [];
					keys[i][0] = healthData[i][sortingKey];
					keys[i][1] = i;

				}
				keys.sort();
				keys.reverse();

				for ( var i in keys) {
					sortedData.push(healthData[keys[i][1]]);
				}
				return sortedData;
			},
			/**
			 * Name: getFormattedData Purpose: formats the sorted health data to
			 * key value pairs based on measurement date. Params: takes sorted
			 * health data as parameter Returns: returns the formatted hash
			 * object
			 */
			getFormattedData : function(sortedData) {
				mHealth.util.logMessage('Set the Formatted Data');
				var healthDataObjects = new Object();
				var len = sortedData.length;
				var child;
				if (this.healthDataTracker == 'A1c'
						|| this.healthDataTracker == 'Blood Glucose'
						|| this.healthDataTracker == 'Microalbumin'
						|| this.healthDataTracker == 'Foot Exam - Provider'
						|| this.healthDataTracker == 'Dilated Retinal Exam'
						|| this.healthDataTracker == 'Foot Sores') {
					for ( var i = 0; i < len; i++) {
						child = new Object();
						child['measurementDate'] = sortedData[i]['measurementDate'];
						child['value'] = sortedData[i]['value'];
						child['comments'] = sortedData[i]['comments'];
						healthDataObjects[sortedData[i].measurementDate] = child;
					}
				} else {
					var key;
					for ( var i = 0; i < len; i++) {
						key = sortedData[i].measurementDate;
						if (healthDataObjects.hasOwnProperty(key)) {
							if (child['measurementDate'] == key)
								child[sortedData[i].healthDataType] = sortedData[i].value;
						} else {
							child = new Object();
							child['comments'] = sortedData[i].comments;
							child['measurementDate'] = sortedData[i].measurementDate;
							child[sortedData[i].healthDataType] = sortedData[i].value;
						}
						healthDataObjects[key] = child;
					}
				}
				return healthDataObjects;
			},
			/**
			 * Name: getJournalFailure Purpose: Failure callback function for
			 * get journal data. Params: Implicit callback function params
			 * Returns: Doesn't return
			 */
			getJournalFailure : function(jqXHR, textStatus, errorThrown) {
				mHealth.util.logMessage('On Journal Failure');
				mHealth.util.hideMask();
			},
			/**
			 * Name: setGlucoseTracker Purpose: Opens detailtracker.html when
			 * blood glucose icon is clicked on home page. Sets the
			 * healthDataTracker to Blood Glucose. Params: No params Returns::
			 */
			setGlucoseTracker : function(event) {
				mHealth.util.logMessage('On Glocose Tracker');

				this.healthDataTracker = 'Blood Glucose';

				mHealth.GraphControllerObject.healthDataTracker = 'Blood Glucose';

				var view = event.target;

				var trackerName = $(view).parents('div').children('div')
						.children('h1').text();

				if (trackerName != 'Glucose' && trackerName != '') {

					this.healthDataTracker = trackerName;
					mHealth.GraphControllerObject.healthDataTracker = trackerName;
				}

				this.loadTrackerDataForTracker();
				// $.mobile.changePage('../../trackers/view/detailtracker.html');

			},
			participantFailure : function() {
				mHealth.util.logMessage('On Participant failure');
				mHealth.util.hideMask();
				mHealth.util.customAlert(
						mHealth.SettingsController.msgErrorCommunication, '');

			},
			/**
			 * Name : participantSuccess Purpose : Success callback for getting
			 * participant data. Params : output - response from the server
			 * Returns : --
			 */
			participantSuccess : function(output) {
				mHealth.util.logMessage('On Participant Success');
				/*
				 * FOLLOWING CODE IS COMMENTED OUT FOR DISABLING SHOWING
				 * PROGRESS BAR AND THE WELCOME MESSAGE
				 */
				var response = output.responseText;

				mHealth.models.ParticipantModel.customFromJSON(response);

				var participant = mHealth.models.ParticipantModel.first();
				mHealth.util.hideMask();
				if (participant.height == "" || participant.height == undefined) {
					mHealth.util.heightFlag = false;

					mHealth.util.loadHomeBar();
					$.mobile.changePage('../../home/view/profile.html');
				} else {
					$.mobile.changePage('showtrackertrack.html');
				}
			},
			/**
			 * Name: viewNewEntry Purpose: changes page to showtrackertrack.html
			 * or profile.html based on trackertype and participant height
			 * value. Params: No params Returns: Doesn't return
			 */
			viewNewEntry : function() {
				mHealth.util.logMessage('On new Entry Page');
				if (this.healthDataTracker == "Weight & BMI") {
					var participant = mHealth.models.ParticipantModel.first();
					if (participant == undefined || participant == null) {
						mHealth.util.showMask();
						this.proxy(this.service.getResponse(
								mHealth.env.message_get_url, this
										.proxy(this.participantSuccess), this
										.proxy(this.participantFailure), true));
					} else if (participant.height == ""
							|| participant.height == undefined
							|| participant.height == 0) {
						mHealth.util
								.customAlert(
										mHealth.SettingsController.msgNoHeight,
										function() {
											mHealth.util.loadHomeBar();
											// if(isAndroid){
											// nativeCommunication.callNativeMethod("tabbar://loadHome?");
											// }else if(isIOS){
											// nativeCommunication.callNativeMethod("tabbar://Home?");
											// }
											$.mobile
													.changePage('../../home/view/profile.html');
										});
					} else {
						$.mobile.changePage('showtrackertrack.html');
					}
				} else {
					$.mobile.changePage('showtrackertrack.html');
				}
			},
			/**
			 * Name :getTrackers Purpose : Load the trackers based on the value
			 * from the server Params : -- Returns : --
			 */
			getTrackers : function() {
				mHealth.util.logMessage('On GetTrackers function');
				// var trackers =
				// mHealth.models.FeatureGroupModel.findByAttribute("groupId",
				// "trackers");
				$.mobile.changePage("../../trackers/view/showtracker.html");
				mHealth.util.loadTrackerbar();

			},
			/**
			 * Name :showTrackers Purpose : Display the trackers in the page
			 * Params : -- Returns : --
			 */
			showTrackers : function() {
				mHealth.util.logMessage('On ShowTracker function');
				examsList = [];
				var trackerFeature = mHealth.models.FeatureGroupModel
						.findByAttribute('groupId', 'trackers');
				var trackersData = [];
				// var trackersData = trackerFeature.feature;
				if (trackerFeature.feature != undefined
						|| trackerFeature.feature != null) {
					for ( var i = 0; i < trackerFeature.feature.length; i++) {
						if (trackerFeature.feature[i].id
								.match(/tracker-exam-.*/)) {
							examsList.push(trackerFeature.feature[i]);
						} else {
							trackersData.push(trackerFeature.feature[i])
						}
					}

					var trackersVal = mHealth.util.getSortData(trackersData);
					var examsList = mHealth.util.getSortData(examsList);
					mHealth.util.examsList = examsList;
					if (trackersVal) {
						$('#trackersValue').html(
								_.template($('#trackersList').html(), {
									trackersVal : trackersVal
								}));
						$('#trackersValue').trigger('create');
					}
				}
			},
			showExamsList : function() {
				if (mHealth.util.examsList) {
					$('#examValue').html(_.template($('#examList').html(), {
						examsList : mHealth.util.examsList
					}));
					$('#examValue').trigger('create');
				}
			}
		});
