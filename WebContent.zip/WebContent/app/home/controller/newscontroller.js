/**
* Controller : NewsController
* Controller to do the  logic of conditions
**/

mHealth.controllers.NewsController = Spine.Controller.sub({
    el : 'body',
                                                          
    prevArtclId             : "0",// Swipe support
    nextArtcleId            : "0",
    articleIdVal            : "",
    categoryArtLengthFlag   : '',//total articles count in selected Category
    currCategoryNmFlag      : '',//selected Category Name
    currArticleIndexFlag    : "",//current page index(+1) used for page count
                                                          
    service : mHealth.util.RemoteServiceProxy.getInstance(),
    events : {
        'click #showNewsPage'       : 'getNewsListData',
        'click #newsIconId'         : 'showNewsDisclaimer',
        'pagebeforeshow #shownews'  : 'showNewsDataList',
        'click #showArticleDetail'  : 'loadArticle',
        'swiperight #shownewsdetail': 'loadArticleFromSwipe',
        'swipeleft  #shownewsdetail': 'loadArticleFromSwipe',
        'click #detailsArticleBack' : 'getNewsListData',
        'vclick .linkOutOfNews'     : 'parseArticle',
        'pageshow #shownewsdetail'  : 'addScrollForNewsItem',
        'pagehide #shownewsdetail'  : 'removeScrollForNewsItem'

    },
    /**
	 * Name    : removeTermsOfUseScroll
	 * Purpose : Method to unbind the touchmove for scrolling to work after going out of terms of use page.
	 * Params  : --
	 * Return  : --
	 **/
	removeScrollForNewsItem : function() {
		$(document).unbind('touchmove', mHealth.util.prevDefault());
    },  
    
    addScrollForNewsItem : function (){
                                                          
    	$('#articleScroller').css({
            'height': '100% !important',
            'width' : '100%',
            'background' : 'white',
            'top':'39px'
            });
//        $('#articleScroll').css({'height': '100%'});
        mHealth.util.logMessage("Building the scroll for News Details");
        newsScroll = new iScroll('articleScroller', {bounce : false,checkDOMChanges: false});
        $(document).bind('touchmove', mHealth.util.prevDefault());
      
    },
    showNewsDisclaimer : function() {
        mHealth.util.customAlert("This news feed is customized by your current conditions.", '');
    },
    showHomepage:function(){
        $.mobile.changePage("../../home/view/home.html");
        mHealth.util.loadHomeBar();
    },                                                  

    /**
       * Name : getNewsListData
       * Purpose : Method to get the response for news articles 
       * Params : -- 
       * Returns : --
       */
    getNewsListData : function() {
        mHealth.util.showMask();
                                                          
        var URL;
        URL = mHealth.env.news_url;
        mHealth.util.logMessage('On getNews function - Calling the service for URL ' + URL);
        
        this.service.getResponse(URL, this.proxy(this.newsSuccess), this.proxy(this.newsFailure), true);
                                                                                                                   
    },
      /**
       * Name    : newsFailure
       * Purpose : Error callback of news articles service call
        * Params  : jqXHR - XMLHttpRequestObject, textStatus - Status text message of the response, errorThrown - Error message recieved from the server
       * Returns : Alerts 'Information not available'
       **/
      newsFailure : function(jqXHR, textStatus, errorThrown) {
          mHealth.util.logMessage('Inside newsFailure method');	
          mHealth.util.hideMask();
          mHealth.util.customAlert(mHealth.News.informationErrMsg, '');
      },
      
      /**
       * Name    : newsSuccess
       * Purpose : Success callback of newsSuccess service call
       * Params  : output - response from the server
       * Returns : --
       **/
    newsSuccess : function(output) {
      mHealth.util.logMessage('Inside newsSuccess method');
      
      	mHealth.models.CategoryModel.destroyAll();
        mHealth.models.ArticleModel.destroyAll();
          
       var response = output.responseText;
    
       if ((response.length > 0 ) && (response != undefined || response != null || response != "")) {
           var newsData = JSON.parse(response);
           	    
	       //populate category name on the collapsable control and then populate the list
	       if (newsData.categories) {
	          var categoryObject = newsData.categories;

	          for (var i=0; i < categoryObject.length; i++) {
		          var catName = categoryObject[i].name;
		          var catPrior = categoryObject[i].priorityCategory;
		          var catArticle = categoryObject[i].articles;
		      } 
	          mHealth.models.CategoryModel.customFromJSON(categoryObject);
	          mHealth.models.ArticleModel.customFromJSON(catArticle);
	       }
          
         //  this.showNewsDataList();
          $.mobile.changePage("../view/shownews.html");
          mHealth.util.hideMask();
       } else {
         $.mobile.changePage("../view/shownewsnotfound.html");
       }  
    },
                                                          
                                                          
      /**
       * Name    : showNewsDataList - populated in the shownews.html
       * Purpose : Display the news page; display category name  and the articles list for each category
       * Params  : --
       * Returns : --
       **/                                                      
    showNewsDataList : function() {
    	mHealth.util.logMessage('On showNewsDataList function');

    	mHealth.util.loadHomeBar();
    	mHealth.util.logMessage('Loaded Home Bar') 
        
    	catData = mHealth.models.CategoryModel.all();
    	
//    	REMOVED as now we use Category Model only and build the list in the shownes.html
//    	mHealth.models.CategoryModel.each(function(catData) {
//               for (i = 0; i < catData.articles.length; i++) {
//                   var tt = catData.articles[i].title;
//                }
//               $('#news_div').html(_.template($('#newsCatList').html(), {
//                   catData : catData
//                   
//               }));

//		      $('#news_div').html(_.template($('#newsCatList').html(), {
//		          catData.articles : catData
//		      }));
//		    
//        });
//    	
//   articlesData = mHealth.models.ArticleModel.all();
        
        $('#news_div').html(_.template($('#newsCatList').html(), {
            catData : catData
            
        }));
          
        $('#shownews').trigger('create');
     },
   
                                                       
                                                           
/**
 * Name : loadArticle; on the click event of the selected article, pass ID and make a service call; 
 * set value of selectedArticleId into global variable= 'articleIdVal' to be used later in swipe functionality
 * Purpose : Calls webservice to get article details page
 * Params : --
 * Return : --
 */
  loadArticle : function(e) {
                                                          
      mHealth.util.scrollTop = $(window).scrollTop();
      mHealth.util.currentIndex=$(e.currentTarget).index()+1;
      mHealth.util.showMask();
                                                          
    var eventTarget = event.target;
                                                          
    
    //set ID of the selected article to a global variable for swipe functionality
    var articleID = $(eventTarget).parents().children('input[id="articleIdHdn"]').val();
    	articleIdVal = articleID;
                                                    
    var counterIndexID =  $(eventTarget).parents().children('input[id="articleIndexHdn"]').val();
    	currArticleIndexFlag = counterIndexID;

    var categoryNameVal =  $(eventTarget).parents().children('input[id="catNameHdn"]').val();	
    	currCategoryNmFlag = categoryNameVal;
    	
    var artclCategoryLengthVal =  $(eventTarget).parents().children('input[id="catLengthHdn"]').val();
    	categoryArtLengthFlag = artclCategoryLengthVal;    	
    	
    mHealth.NewsControllerObject.loadArticleDetailById(articleID);
  },



/**
   * Name : loadArticleDetailById
   * Purpose : Loads article details in to model
   * Params : accepting articleId from LoadArticle() and passing it in the request
   * Return : either successful .html or a failed request
   */
  loadArticleDetailById : function(articleID) {
//	  error handling when articledID fails else proceed with the service call
     mHealth.util.logMessage('Inside loadArticleDetailById where  articleID = ' +articleID);
                                                          
                                                          
	  if (articleID == undefined || articleID == null || articleID == '') {
	    	this.noArticleToDisplay();
	  } else {                                                  
		  var URL  = mHealth.env.newsdetail_url + articleID;
                                                          
		 this.proxy(this.service.getResponse(URL, mHealth.NewsControllerObject.displayArticleSuccess, mHealth.NewsControllerObject.noArticleToDisplay, true));
		 $.mobile.changePage("../view/shownewsdetail.html");
      }
},

                                                           
 /**
  * Name : displayArticleSuccess
  * Purpose : Display content of selected article; display page count
  * Params : --
  * Return : --
  */
   displayArticleSuccess : function(output) {
                                                          
    var articleDetail = output.responseText;

  //display page count; reset indexing to start at 1 instead of 0
    var pageCount = parseInt(currArticleIndexFlag) + 1;
    var totalCnt =  parseInt(categoryArtLengthFlag);
    $('#showArticleCount').html(currCategoryNmFlag + ':  ' +  pageCount + ' / ' + totalCnt);
   
 //populate article content
    $('#articledetails').css({'display':'block'});  //to prevent empty div (white line) while article is loading
          
//
                                                          
                                                          
//    mHealth.util.newsScroll = new Scroller("#articledetails");
//    $(document).bind('touchmove', mHealth.util.prevDefault());
//    
//    $('#termsBackButton').click(function(e){
//     mHealth.util.logMessage("terms of Use back button clicked");
//     $(document).unbind('touchmove', mHealth.util.prevDefault());
//     // mHealth.util.forceQuit();
//    });
//                                                          
    mHealth.util.logMessage('Inside articledetails Populating article content');
    
    
	$('#article_data').html(_.template($('#article_script').html(),{
		articleDetail : articleDetail
		}));
//	   $('#articledetails').html(articleDetail).html();
    $('#shownewsdetail').trigger('create');
    mHealth.util.hideMask();
  
  },
             
  /**
   * Name : noArticleToDisplay
   * Purpose : Display notification to a user if service call fails
   * Params : --
   * Return : --
   */
  noArticleToDisplay : function(){
    mHealth.util.logMessage('Inside noArticleToDisplay method');
    mHealth.util.hideMask();
    mHealth.util.customAlert(mHealth.News.informationErrMsg, '');
  },
 
  
  /**
   * Name : parseArticle 
   * Purpose : parsing article's content to replace target="_new"   with class="newsArticle"
   * Params : -- 
   * Return : --
   * COMMENT : Include hideMask if URL is opened multiple times to prevent spinning wheel
  */
  parseArticle : function(event) {
    var target = event.target || event.srcElement;
    if (target.href) {
      var targetValue = target.href;
      assetID = targetValue;

      window.open(mHealth.IOSURL+assetID, '_blank');
      return false;   //return false to prevent the loading of the spinner (showMask()) 
    } else {
          mHealth.util.customAlert("No url found to navigate", '');
    }
      
//      !!! TO DO !!!  display a warning to a user about redirect. Currently is not working; the buttons on the alert 'freeze' 
//      mHealth.util.customPrompt(mHealth.News.userWarningAlert,
//        function() {
//              //NO selected, stay on the screen
//    	  },
//            function() {   //YES is selected
//            	  window.open(mHealth.IOSURL+assetID, '_blank');    
//            	  } else {
//                 mHealth.util.customAlert(mHealth.News.userConnectionError, '');
//                 }
//      );
      
  },
  
//SWIPE FUNCTIONALITY
  /**
   * Name : loadMessageFromSwipe
   * Purpose :
   * Params : --
   * Return : --
   */
  loadArticleFromSwipe : function(event) {
    this.toNextArticle(event);
 },
  
  /**
   * Name : toNextMessage
   * Purpose : move to the next available message
   * Params : --
   * Return : --
   */
  toNextArticle : function(event) {
                                                           
    mHealth.util.showMask();
    var myArticleId = null;
    articleIdVal = '';
  
    var tempModel  =  mHealth.models.CategoryModel.all();
    var currCatCnt = categoryArtLengthFlag;
   
    var newArticleIndexFlag;
    newArticleIndexFlag = parseInt(currArticleIndexFlag);
    
    mHealth.models.CategoryModel.all().forEach(function(cat) {
        	
    if (cat.name == currCategoryNmFlag) {
    	articlesList = cat.articles; 
        	
    	//store value of current article to be passed to the swipe event so it knows ID selected
    	for (var tempId = 0; tempId < articlesList.length; tempId++ ) {
    		currentArticle = articlesList[tempId];
     		articleIdVal = currentArticle.id;
			mHealth.util.logMessage('in toNextArticle function  articleIdVal = ' + articleIdVal +  ' currCatCnt ' + currCatCnt);
			if (event.type == "swipeleft") {     
				if ((tempId)==parseInt(currArticleIndexFlag)+ 1) {
					myArticleId = articleIdVal;
				    newArticleIndexFlag = parseInt(currArticleIndexFlag) + 1;  //increment index to move to the next
				    mHealth.util.logMessage('swipeLEFT - tempId ' + tempId + ' moving to newArticleIndexFlag ' + newArticleIndexFlag);
				}
			} 
			if (event.type == "swiperight") {
				if ((tempId)==parseInt(currArticleIndexFlag) -1) {
					myArticleId = articleIdVal;
				    newArticleIndexFlag = parseInt(currArticleIndexFlag) - 1;
				    mHealth.util.logMessage('swipeRIGHT - tempId ' + tempId + ' moving to newArticleIndexFlag ' + newArticleIndexFlag);
				}
				//reset to the 1st article ID when reaching beginning of the list on the swiperight
			}
	     };//End of FOR
	    //When at the start or end of the list, pass to the articleID so it keeps loading; last ID for swipeleft; 1st articleID/0 index for swiperight. 
	    if (myArticleId == null ) {
	        if (event.type == "swiperight") {
	        	myArticleId = articlesList[0].id;
	        } else {
	        	myArticleId = articlesList[newArticleIndexFlag].id;
	       	}
        }
      }
    });
    currArticleIndexFlag = newArticleIndexFlag;
    mHealth.util.logMessage(' FINAL myArticleId:  ' +  myArticleId );
    mHealth.NewsControllerObject.loadArticleDetailById(myArticleId );
  },
  
  });//end controller