/**
 * Controller :Participant controller Logic for profile is done here
 */
mHealth.controllers.ParticipantController = Spine.Controller.sub({
	el 		: 'body',
	preferredName : '',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events 	: {
		'click #showProfile' 			: 'getProfileData',
		'click #saveProfile' 			: 'saveProfileData',
		'pagebeforeshow #profilePage' 	: 'showProfileData',
		'pageshow #profilePage' 		: 'processData',
		'submit #participantForm' 		: 'doSubmit',
		'keyup #preferredName'          : 'onKeyPress'
	},
	
	onKeyPress: function(event){
	
	var preferredName1=$('#preferredName').val();
	
	if (preferredName1.search(/^[a-zA-Z ]*$/)) {

	}
	else
	{
		this.preferredName=preferredName1;
	}
	$('#preferredName').val(this.preferredName);
	},
	
	/**
	 * Name : doSubmit
	 * Purpose : This is for the go button to work 
	 * profile Params : -- Returns : --
	*/
	doSubmit : function(event) {
		mHealth.util.logMessage('On do submit function');
		this.saveProfileData();
		event.preventDefault();
	},

	/**
	 * Name : getProfileData Purpose : Method to get the response for
	 * profile Params : -- Returns : --
	*/
	getProfileData : function() {
		mHealth.util.showMask();
		mHealth.util.logMessage('On getProfileData function');
		this.service.getResponse(mHealth.env.profile_url, this.proxy(this.participantSuccess), this.proxy(this.participantFailure), true);
	},

	/**
	 * Name : participantSuccess Purpose : Success callback for getting
	 * participant data. Params : output - response from the server
	 * Returns : --
	*/
	participantSuccess : function(output) {
		mHealth.util.logMessage('On participantSuccess function');
		var response = output.responseText;
		mHealth.models.ParticipantModel.destroyAll();
		mHealth.models.ParticipantModel.customFromJSON(response);
		mHealth.util.hideMask();
		$.mobile.changePage("../../home/view/profile.html");
	},

	/**
	 * Name : participantFailure Purpose : Failure callback for getting
	 * participant data Params : jqXHR - XMLHttpRequestObject,
	 * textStatus - Status text message of the response, errorThrown -
	 * Error message recieved from the server Returns : Alerts
	 * 'Information not available'
	*/
	 participantFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.logMessage('On participantFailure function');
		mHealth.util.customAlert(mHealth.Condition.informationErrMsg,'');
		mHealth.util.hideMask();
	},

	/**
	 * Name : showProfileData Purpose : Method to render profile data
	 * Params : -- Returns : --
	*/
	showProfileData : function() {
		
		mHealth.util.logMessage('On showProfileData function!!!!!!');
		mHealth.util.loadHomeBar();
		var profileDetail = mHealth.PersonalInfo;
		$('#profileHeader').html(_.template($('#headerScript').html(), {
			profileDetail : profileDetail
		}));
		var participantData = mHealth.models.ParticipantModel.all();
		$('#profiles').html(_.template($('#participantList').html(), {
			participantData : participantData
		}));

		$('#profileHeader').trigger('create');
		$('#profiles').trigger('create');
	},

	/**
	 * Name : saveProfileData Purpose : Method to update profile data in
	 * model Params : -- Returns : --
	*/
	saveProfileData : function() {
		mHealth.util.logMessage('IN SAVE PROFILE DATA');
		if (mHealth.SettingsAbout.networkStatus != 'false') {
			var emailFlag;
			var participantData = mHealth.models.ParticipantModel.first();
			var tempEmailId = participantData.emailAddress;
			var tempPrefName = participantData.preferredName;
			var tempHeight = participantData.height;
			mHealth.util.logMessage('On saveProfileData function tempHeight ::'	+ tempHeight);
			var emailReg = /^([A-Za-z0-9\.])+\@([A-Za-z0-9\.])+\.([A-Za-z]{2,4})$/;
			var validEmailFlag = false;
			
			// Only Update the profile if the User Changes
			var emailValue = $("#email").val().trim();
            mHealth.util.logMessage("emailValue  ::"+emailValue+"::");
			if (emailValue != null && emailValue != '') {
				emailFlag = emailReg.test(emailValue);
			} else {
				emailFlag = true;
			}
			
			var heightFlag = true;
			if ($('#height').val() == '0') {
				heightFlag = false;
			}

			if (emailFlag == false) {
				mHealth.util.customAlert(mHealth.Validation.emailValidation, '');
			} 
			else if (emailFlag == true && heightFlag == true) {
				if (!(tempPrefName == $("#preferredName").val()) || !(tempEmailId == $("#email").val()) || !(tempHeight == $('#height').val())) {
					mHealth.util.showMask();
					mHealth.index = $('select#height option:selected').val();
					var hDataObject = mHealth.recommendation.ParticipantMapper(mHealth.models.ParticipantModel.first().participantID,mHealth.index);
					mHealth.util.logMessage(" HEALTHDATA OBJECT"+ hDataObject);
					this.service.postRequest((mHealth.env.healthdata_url + "Height"),hDataObject, this.proxy(this.heightSaveSuccess),this.proxy(this.heightSaveFailure), true);
					
					var pDataObject = mHealth.recommendation.ParticipantPostMapper($("#preferredName").val().trim(), $("#email").val());
					mHealth.util.logMessage(" PROFILEDATA OBJECT"+ pDataObject);
					this.service.postRequest(mHealth.env.profile_url,pDataObject, this.profileSaveSuccess,this.profileSaveFailure, false);
					participantData.updateAttributes({
						preferredName : $("#preferredName").val().trim(),
						emailAddress : $("#email").val(),
						height : $('select#height option:selected').val()
					});
					$.mobile.changePage("../../home/view/home.html");
				} else {
						$.mobile.changePage("../../home/view/home.html");
				}
			}else if (heightFlag == false) {
				mHealth.util.customAlert(mHealth.Validation.heightValidation, '');
			}
		} else {
				mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError,'');
			}
	},

	/**
	 * Name: profileSaveFailure Purpose: Failure callback function for
	 * saving profile data Params: Implict failure callback params
	 * Returns: Doesn't return
	*/

	profileSaveFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.logMessage('On profileSaveFailure function');
		mHealth.util.customAlert(mHealth.SyncProcessController.msgErrorCommunication,'');
		mHealth.util.hideMask();
	},

	/**
	 * Name: profileSaveSuccess Purpose: success callback function for
	 * saving profile data Params: output from postRequest as implicit
	 * param Returns: Doesn't return
	*/
	profileSaveSuccess : function(output) {
		mHealth.util.logMessage('On profileSaveSuccess function');
		mHealth.util.hideMask();
	},

	/**
	 * Name: heightSaveFailure Purpose: Failure callback function for
	 * saving profile data Params: Implict failure callback params
	 * Returns: Doesn't return
	*/
	heightSaveFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.logMessage('On heightSaveFailure function');
		mHealth.util.customAlert(mHealth.SyncProcessController.msgErrorCommunication,'');
		mHealth.util.hideMask();
	},

	/**
	 * Name: heightSaveSuccess Purpose: success callback function for
	 * saving profile data Params: output from postRequest as implicit
	 * param Returns: Doesn't return
	*/
	heightSaveSuccess : function(output) {
		mHealth.util.logMessage('On heightSaveSuccess function');
		var response = output.responseText;
		var responses = JSON.parse(response);
			$.mobile.changePage("../../home/view/home.html");
			mHealth.util.hideMask();
	},

	/**
	 * Name : processData Purpose : Method to process height units from
	 * settings controller Params : -- Returns : --
	*/
	processData : function() {
		mHealth.util.hideMask();
		mHealth.util.logMessage('On processData function');
		var index = "-1";
		if (mHealth.models.ParticipantModel.first()) {
			mHealth.index = mHealth.models.ParticipantModel.first().height;
			if (mHealth.util.selUnits == undefined || mHealth.util.selUnits == mHealth.PersonalInfo.ft) {
				if (mHealth.index != undefined || "") {
					setHeight(mHealth.PersonalInfo.ft,	(mHealth.index - 36));
				} else {
					setHeight(mHealth.PersonalInfo.ft, index);
				}
			}
			if (mHealth.util.selUnits == mHealth.PersonalInfo.cm) {
				if (mHealth.index != undefined || mHealth.index == "") {
					setHeight(mHealth.PersonalInfo.cm,(mHealth.index - 36));
				} else {
					setHeight(mHealth.PersonalInfo.cm, index);
				}
			}
		}
		
		this.preferredName=$('#preferredName').val();
		
		$('#profilePage').css({'height' : 'auto !important'});
	}
});