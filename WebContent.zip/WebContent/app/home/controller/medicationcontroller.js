/**
 * Controller : MedicationController This is the controller to do the logic of
 * medications
 */
mHealth.controllers.MedicationController = Spine.Controller.sub({
   el : 'body',
   service : mHealth.util.RemoteServiceProxy.getInstance(),
   allMeds          : "all",
   currentMeds      : "current",
   disregMeds       : "disregarded",
   reconileMeds     : "reconciliation",
   discontinuedMeds : "discontinued",
   discMeds         : "discMedications",
   detailedMedicationstring : null,
   detailedMedications : null,
   frequency : null,

   events : {
				'click #show_medication'            	: 'displayMedication',
				'click #add_medications'            	: 'displayNativeMedicationList',
				'click #current_medication'         	: 'getMedicationList',
				'click #claims_medication'          	: 'showClaimMedication',
				'click #archieved_medication'       	: 'showArchievedMedication',
				'pagebeforeshow #search_medication' 	: 'loadDataForGlobalMedicationSearch',
				'change #claim_avail'               	: 'selectedOption',
				'change #claim_avail1' 		          	: 'selectedOption',
				'change #frequency'                 	: 'getFrequencyValue',
				'change #refill_frequency'          	: 'getRefilFrequencyValue',
				'change .archived_currentMedication'	: 'getArchievedtoCurrentMedication',
				'pagebeforeshow #add_medication'    	: 'addMedicationPostProcess',
				'pagebeforeshow #View_medication'   	: 'renderClaimPoints',
				'pageshow #add_medication'          	: 'addMedicationPageShow',
				'pageshow #detail_medication' 			: 'addMedicationPageShow',
				'pagebeforeshow #medication_index' 		: 'showMedicationList',
				'pagebeforeshow #medication_claim' 		: 'renderClaimMedication',
				'pagebeforeshow #medication_archived' 	: 'renderArchieveMedication',
				'click .medicationUniqueId' 			: 'getDetailedMedication',
				'pagebeforeshow #detail_medication' 	: 'showDetailedMedication',
				'click #removeMedication' 				: 'removeMedication',
				'click .deletesource' 					: 'confirmRemoveMedication',
				'click .deletebutton'					: 'removeMedicationModel',
				'click .cancelBut'						: 'showMedicationList',
				'click .doneBut' 						: 'showMedicationList',
				'click #saveMedication' 				: 'addMedication',
				'click #searchMedications' 				: 'callMedicationSearchPage',
				'swipeleft .medication' 				: 'showHideDeleteButton',
				'swiperight .medication' 				: 'showHideDeleteButton',
				'click #medicationRemove' 				: 'removeMedicationModel',
				'click #add_medication_back' 			: 'addMedicationBack',
				'click #detailMedicationSave' 			: 'detailMedicationAdd',
				'click #displayMonoGram' 				: 'getMedicationMonograph',
				'pagebeforeshow #medication_monograph' 	: 'populateMonographPage',
				'click #medDetailBack' 					: 'validateDetailMedication',
				'pagebeforehide #detail_medication'     : 'validateDetailMedication',
				'click #monographBack'                  : 'monographBack',
				'pagehide #medication_monograph'        : 'removeMonoGramScroll',
				'pageshow #medication_monograph'        : 'addIscroll',

			},
			
			
			addIscroll: function(){
				$('#monogramScroll').css({
		            'height': '100% !important',
		            'width' : '100%',
		            'background' : 'white',
		            'top':'41px'
		        });
			mHealth.util.monoScroll = new iScroll('monogramScroll', {
	           bounce : false,
	           checkDOMChanges: false
	        });
	        $(document).bind('touchmove', mHealth.util.prevDefault());
			},
			
			/**
			 * Name    : removeTermsOfUseScroll
			 * Purpose : Method to unbind the touchmove for scrolling to work after going out of terms of use page.
			 * Params  : --
			 * Return  : --
			 **/
			removeMonoGramScroll : function() {
				mHealth.util.logMessage("Going out of the page removeMonoGramScroll");
				$(document).unbind('touchmove', mHealth.util.prevDefault());
		    },  
			
			monographBack : function()
			{
				  this.detailedMedicationstring = JSON.stringify(this.detailedMedications);
				  var encodeMedicationData = $.base64Encode(this.detailedMedicationstring);
				   $.mobile.changePage("../view/medicationdetails.html");
			},

			validateDetailMedication : function(event) {
				var isDirtyForm=false;
				var startDate = $('#startDate').val();
				var endDate = $('#endDate').val();
				var frequency=$('select#frequency option:selected').val();
				var refillFrequency=$('select#refill_frequency option:selected').val();
				var dosage=$('select#dosageAmount option:selected').val();
				if (this.detailedMedications.startDate == undefined) {
					this.detailedMedications.startDate = "";
				}
				if (this.detailedMedications.refillFreqId == undefined) {
					this.detailedMedications.refillFreqId = "Please select one";
				}
				if (this.detailedMedications.freqId == undefined) {
					this.detailedMedications.freqId = "Please select one";
				}
				if (this.detailedMedications.dosage == undefined) {
					this.detailedMedications.dosage = "Please select one";
				}
				if (this.detailedMedications.endDate == undefined) {
					this.detailedMedications.endDate = "";
				}
				
				if(startDate!=this.detailedMedications.startDate)
					{
					isDirtyForm=true;
					}
				if(endDate!=this.detailedMedications.endDate)
					{
					isDirtyForm=true;
					}
				if(this.detailedMedications.dosage=='Please select one')
					{
					
					if(dosage!='Please select one')
						{
						isDirtyForm=true;
						}
					}
				else if(parseInt(this.detailedMedications.dosage)!=parseInt(dosage))
					{
						isDirtyForm=true;
					}
				if(this.detailedMedications.freqId!=frequency)
				{
					isDirtyForm=true;
				}
				if(this.detailedMedications.refillFreqId!=refillFrequency)
				{
				isisDirtyForm=true;
				}
				
				if (isDirtyForm==true) {
					mHealth.util.customPromptForMedDetails(mHealth.Medication.unsavedDetailmedication,
							function() {
//								$.mobile.changePage("medicationindex.html");
							}, function() {
								mHealth.MedicationControllerObject.detailMedicationAdd();
							});
				} else {
					$.mobile.changePage("medicationindex.html");
				}
			},

			renderClaimPoints : function() {

				if (mHealth.Medication.claim == null|| mHealth.Medication.claim == "") {
					$('#claimPoints').hide();
				} else {
					$('#claimPointsDiv').html(_.template($('#claimPointsScript').html()));
					$('#View_medication').trigger('create');
				}
			},
			
            getMedicationMonograph : function() {
				mHealth.util.logMessage('Inside getMedicationMonograph !!');
				mHealth.util.showMask();
				this.service.getResponse("http://secure.uat.alerehealth.com:13085/api/medicationmonograph/?filter="+ this.detailedMedications.medicationId,this.monographSuccess, this.monographFailure,	false);
            },
			
			monographSuccess : function(output) {

				mHealth.util.hideMask();

				mHealth.util.logMessage('sucess');

				var response = output.responseText;

				var monographData = JSON.parse(response);// .responseText;
				
				mHealth.models.MonographModel.destroyAll();
				
				mHealth.models.MonographModel.customFromJSON(monographData);

				$.mobile.changePage("../view/monograph.html");

			},
			populateMonographPage : function() {

				mHealth.util.logMessage('populateMonographPage');

				var monograph_Data = mHealth.models.MonographModel.all();

				$('#medication_monograph_data').html(_.template($('#monograph_data').html(),{
					monographData : monograph_Data
					}));
				$('#medication_monograph').trigger('create');

			},
			monographFailure : function() {
				
				mHealth.util.hideMask();
				
				mHealth.util.logMessage('failure');

			},
			addMedicationBack : function(event) {
				
				var isDirtyForm=false;
				
				mHealth.util.logMessage('Inside addMedicationBack !!');

				var dosageAmount = $('select#dosageAmount option:selected').val();
				
				if(mHealth.Medication.dosage!='Dosage' )
						{
						if(dosageAmount !=mHealth.Medication.dosage){
							isDirtyForm=true;
						}
				}else if (dosageAmount != "Please select one")
				{
					isDirtyForm=true;
				}

				var frequency = $('select#frequency option:selected').val();
				
				 if(mHealth.Medication.freqId!="" )
					{
							if(frequency !=mHealth.Medication.freqId){
								isDirtyForm=true;
							}
					
					}else if(frequency != "0")
						{
						isDirtyForm=true;
						}

				var refillfrequency = $('select#refill_frequency option:selected').val();

				var startDate = $('#startDate').val();
				
				var endDate = $('#endDate').val();
				
				if(refillfrequency!="4")
				{
					isDirtyForm=true;
				}
					
				if(mHealth.Medication.startDate!="" )
				{
							if(startDate !=mHealth.Medication.startDate){
								isDirtyForm=true;
							}
					
					}
					else if(startDate != "")
						{
						isDirtyForm=true;
						}
					
					if(endDate!="")
						{
						isDirtyForm=true;
						}
					
					if(isDirtyForm==true) {
					mHealth.util.customPrompt(mHealth.Medication.unSavedAddMedication,	function() {
										if (mHealth.Medication.source === 'Self-Reported') {
											$.mobile.changePage("../view/medicationindex.html");
										} else {
											$.mobile.changePage("medicationclaim.html");
										}

									}, function() {

									});
				} else {
					if (mHealth.Medication.source === 'Self-Reported') {
						$.mobile.changePage("../view/medicationindex.html");
					} else {
						$.mobile.changePage("medicationclaim.html");
					}
				}
			},

addMedication : function() {
 mHealth.util.logMessage('Inside addMedication');
             
 var medicationId = mHealth.Medication.medicationId;
 var medicationName = mHealth.Medication.medicationName;
 var dosageAmount = $('select#dosageAmount option:selected').val();
 var frequency = $('select#frequency option:selected').val();
 var refillfrequency = $('select#refill_frequency option:selected').val();
// Source (SOURCEID) = 3 (Claims)
 var source = "1";
 var startDate = $('#startDate').val();
 var endDate = $('#endDate').val();
 var refillFrequencyOther = $('#refilFrequencyOther').val();  
 var frequencyOther = $('#frequencyOther').val(); 
 //alert(" refilFrequencyOther :: "+refilFrequencyOther+ " frequencyOther :: "+frequencyOther);
 if(mHealth.Medication.source == 'Claims'){
	 source="3";
 }
 				
 if(startDate==""|| dosageAmount==0 || frequency==0 || refillfrequency==0){
  mHealth.util.customAlert(mHealth.Validation.generic,'');
 }else{
   if(endDate!=""){ 
    mHealth.util.customPrompt(mHealth.Medication.archieveMedication,function(){
     $('#endDate').val("");
	 endDate="";
	},function(){
        //TODO: the medication with end date should goes to the Archieve Medication
        mHealth.MedicationControllerObject.saveMedicationValue(medicationId, startDate, endDate,dosageAmount, frequency, refillfrequency,source,refillFrequencyOther,frequencyOther);
	    });
	}
	else{
        mHealth.MedicationControllerObject.saveMedicationValue(medicationId, startDate, endDate,dosageAmount, frequency, refillfrequency,source,refillFrequencyOther,frequencyOther);
	    }
	}
},
			
saveMedicationValue : function(medicationId, startDate, endDate,dosageAmount, frequency, refillfrequency,source,refillFrequencyOther,frequencyOther)
{
  var medicationObject = mHealth.models.MedicationModel.findByAttribute('medicationId', medicationId);
  if(medicationObject==null){
    mHealth.util.showMask();
    if(source=="1"){
    	if(mHealth.Medication.previousMedication=='A'){
    var pMedicationObject = mHealth.modelmapper.MedicationArchToAddMapper(medicationId, startDate, endDate,dosageAmount, frequency, refillfrequency,source,refillFrequencyOther,frequencyOther,mHealth.Medication.partMedId);
    mHealth.util.logMessage(" MedicationObject OBJECT"	+ pMedicationObject);
    
	mHealth.MedicationControllerObject.service.postRequest(mHealth.env.medication_url,pMedicationObject, mHealth.MedicationControllerObject.addMedicationSuccess,mHealth.MedicationControllerObject.medicationFailure, false);
	mHealth.Medication.previousMedication="M";
    }
    else
    	{
    	var pMedicationObject = mHealth.modelmapper.MedicationPostMapper(medicationId, startDate, endDate,dosageAmount, frequency, refillfrequency,source,refillFrequencyOther,frequencyOther);
        mHealth.util.logMessage(" MedicationObject OBJECT"	+ pMedicationObject);
    	mHealth.MedicationControllerObject.service.postRequest(mHealth.env.medication_url,pMedicationObject, mHealth.MedicationControllerObject.addMedicationSuccess,mHealth.MedicationControllerObject.medicationFailure, false);
    	}
    }
    else
    	{
    	var medicationObject = mHealth.models.MedicationModel.findByAttribute('medicationID', medicationId);
    	var pMedicationObject = mHealth.modelmapper.MedicationClaimAddMapper(medicationObject,medicationId,startDate,endDate,dosageAmount,frequency,frequencyOther,refillfrequency,refillFrequencyOther);
    	mHealth.MedicationControllerObject.service.postRequest(mHealth.env.medicationfromclaim_url,pMedicationObject, mHealth.MedicationControllerObject.addMedicationSuccess,mHealth.MedicationControllerObject.medicationFailure, false);
    	}
	}
	else{
      mHealth.util.customAlert(mHealth.Medication.medicationDuplicate,function(){
    	  alert(JSON.stringify(medicationObject));
	  this.detailedMedicationstring = JSON.stringify(medicationObject);
	  var encodeMedicationData = $.base64Encode(this.detailedMedicationstring);
	  //TODO: Need to remove the query from this to make it work on Android 3.0 and above.
      $.mobile.changePage("../view/medicationdetails.html");
	 });
   }
},

/**
 * Name: addMedicationSuccess Purpose: success callback function for
 * Adding Medication Data : output from postRequest as implicit
 * param Returns: Doesn't return
 */
addMedicationSuccess : function(output) {
 mHealth.util.logMessage('On addMedicationSuccess function');
 mHealth.MedicationControllerObject.getMedicationList();
 // $.mobile.changePage("../../home/view/medicationindex.html");
 // mHealth.util.hideMask();
},

detailMedicationAdd : function() {
//TODo: Do validation
mHealth.util.logMessage('Inside detailMedicationAdd !!');
				
 var medicationId = this.detailedMedications.medicationId;
 var medicationName = this.detailedMedications.medicationName;
 var dosageAmount = $('select#dosageAmount option:selected').val();
 var frequency = $('select#frequency option:selected').val();
 var startDate = $('#startDate').val();
 var refillfrequency = $('select#refill_frequency option:selected').val();
 var endDate = $('#endDate').val();
 var refillFrequencyOther = $('#refilFrequencyOther').val();  
 var frequencyOther = $('#frequencyOther').val(); 
              
// alert(" refilFrequencyOther :: "+refilFrequencyOther+ " frequencyOther :: "+frequencyOther);

 if(startDate==""||dosageAmount=='Please select one'||frequency=='Please select one'||refillfrequency=='Please select one'){
    mHealth.util.customAlert(mHealth.Validation.generic,'');
 }else{
   if(endDate!=""){
	 mHealth.util.customPrompt(mHealth.Medication.archieveMedication,function(){
	 $('#endDate').val("");
	 endDate="";
	 },
	function(){
	 //TODO: the medication with end date should goes to the Archieve Medication
	 mHealth.util.showMask();
	 var pMedicationObject = mHealth.modelmapper.MedicationUpdateMapper(mHealth.MedicationControllerObject.detailedMedications.partMedId,	medicationId, startDate, endDate, dosageAmount,frequency,refillfrequency,refillFrequencyOther,frequencyOther);
     mHealth.util.logMessage(" MedicationObject OBJECT in detailMedicationADD"	+ pMedicationObject);
	 mHealth.MedicationControllerObject.service.postRequest(mHealth.env.medication_url,pMedicationObject, mHealth.MedicationControllerObject.addMedicationSuccess,mHealth.MedicationControllerObject.medicationFailure, false);
	 });
	}
	else{
		mHealth.util.showMask();
		var pMedicationObject = mHealth.modelmapper.MedicationUpdateMapper(this.detailedMedications.partMedId,	medicationId, startDate, endDate, dosageAmount,frequency,refillfrequency,refillFrequencyOther,frequencyOther);
		mHealth.util.logMessage(" MedicationObject OBJECT FOR UPDATE detailMedicationADD"	+ pMedicationObject);
		this.service.postRequest(mHealth.env.medication_url,pMedicationObject, this.addMedicationSuccess,this.medicationFailure, false);
	}
  }
},

			

			showHideDeleteButton : function(event) {
				var etarget = event.target;

				if ($(etarget).parents().children("div").next().children('.deletebutton').css('display') == 'none') {

					$('.dosecontainer').css({
						'width' : '30% !important'
					});
					$('.ui-block-a').css({
						'width' : '70% !important'
					});
					$(etarget).parents().children("div").next().children('.deletebutton').show();

				} else {

					$('.dosecontainer').css({
						'width' : '0% !important'
					});
					$('.ui-block-a').css({
						'width' : '100% !important'
					});
					$(etarget).parents().children("div").next().children('.deletebutton').hide();

				}
				var medication_ID = $(etarget).parents().children('input[type="hidden"]').val();

				event.stopImmediatePropagation();

				event.preventDefault();
			},

			/**
			 * Name : renderArchieveMedication Purpose : Method to show
			 * medication list. Params : -- Returns : --
			 */
			renderArchieveMedication : function() {
				
				
				var medicationData = mHealth.models.MedicationModel.all();
				$('#archieved_data').html(_.template($('#ArchievedMedicationDataList').html(), {
					medicationData : medicationData
				}));
				$('#medication_archived').trigger('create');
			},

			/**
			 * Name : renderMedication Purpose : Method to show medication list.
			 * Params : -- Returns : --
			 */
			renderClaimMedication : function() {
				var medicationData = mHealth.models.MedicationModel.all();
				$('#claim_data').html(_.template($('#claimMedicationDataList').html(), {
							medicationData : medicationData
				}));
				$('#claims_medication').trigger('create');
			},
			
			callMedicationSearchPage : function() {
				$.mobile.changePage("../view/searchmedication.html");
			},

			loadDataForGlobalMedicationSearch : function(event) {

				mHealth.util.showMask();

				// this.service.getResponse('http://secure.uat.alerehealth.com:13085/api/mastermedications?filter='+mHealth.Medication.searchKey,
				this.service.getResponse('http://secure.uat.alerehealth.com:13085/api/mastermedications?filter=vicks',	this.proxy(this.searchSuccess), this.proxy(this.searchError), true);
			},

			searchSuccess : function(output) {

				mHealth.util.logMessage('Inside search Success method'	+ output.responseText);
				var response = output.responseText;

				this.renderSearchMedication(response);
			},

			renderSearchMedication : function(response) {
				mHealth.util.logMessage('Inside search renderSearchMedication method'+ response);
				var medicationSearchData = JSON.parse(response);

				$('#searchMedication_id').html(_.template($('#medicationSearchList').html(), {
					medicationSearchData : medicationSearchData
				}));
				$('#search_medication').trigger('create');
				mHealth.util.logMessage("AFTER TRIGGER" + medicationSearchData);
				mHealth.util.logMessage("AFTER TRIGGER OBJECT DATA IS "	+ medicationSearchData.medicationId);

			},

			searchError : function(jqXHR, textStatus, errorThrown) {
				mHealth.util.logMessage('Inside medicationsearch error method');
				mHealth.util.hideMask();
				mHealth.util.customAlert(mHealth.Condition.informationErrMsg,'');

			},

			displayNativeMedicationList : function(event) {
				this.detailedMedications=null;
				mHealth.util.showMedicationlList();
			},

			getArchievedtoCurrentMedication : function(event) {
				//alert('Inside the Archived medication');
				if ($('select.archived_currentMedication option:selected').val() == 'Yes') {
					mHealth.util.customPrompt(mHealth.Medication.archievedToCurrentMed,
							function() {
								$('.archived_currentMedication').find("option[value='No']").attr('selected','selected');
								$('select').selectmenu('refresh');
							}, function() {
								$.mobile.changePage("addmedication.html");
							});
				}
			},

			getRefilFrequencyValue : function(event) {
				mHealth.util.logMessage('Inside the option Select');
				if ($('select#refill_frequency option:selected').val() == '5') {
					$('#refilFrequencyOther').show();
				} else {
					$('#refilFrequencyOther').hide();
				}
			},

			getFrequencyValue : function() {
				mHealth.util.logMessage('Inside the option Select');
				if ($('select#frequency option:selected').val() == '24') {
					$('#frequencyOther').show();
				} else {
					$('#frequencyOther').hide();
				}
			},
			
			
			medicationArchSuccess : function(output){
				var response = output.responseText;
				var medicationData = JSON.parse(response);
				mHealth.MedicationControllerObject.setMedicationData(medicationData.MedicationList);
				$.mobile.changePage("addmedication.html");
				mHealth.util.hideMask();
			},
			
			

			selectedOption : function(event) {

				if ($('.ui-page-active').attr('id') == 'medication_archived') {

					if ($('.archieved_avail option[value="Yes"]:selected').val() == 'Yes') {
						
						mHealth.util.customPrompt(mHealth.Medication.archievedToCurrentMed,
								function() {
							$(".archieved_avail option[value='default']").attr("selected", "selected");
							$(".archieved_avail").selectmenu('refresh');
								}, function() {
									mHealth.Medication.previousMedication='A';
									var medicationId = $('.archieved_avail option[value="Yes"]:selected').attr('title');
									mHealth.Medication.source = 'Self-Reported';
									var medicationObject = mHealth.models.MedicationModel.findByAttribute('medicationId', medicationId);
									mHealth.Medication.medicationDesc = medicationObject.medicationName;
									mHealth.Medication.medicationId = medicationId;
									mHealth.Medication.medicationName = medicationObject.medicationName;
									mHealth.Medication.strength = medicationObject.strength;
									mHealth.Medication.route = medicationObject.route;
									mHealth.Medication.form = medicationObject.form;
									mHealth.Medication.startDate = medicationObject.startDate;
									mHealth.Medication.dosage = medicationObject.dosage;
									mHealth.Medication.freqId = medicationObject.freqId;
									mHealth.Medication.partMedId = medicationObject.partMedId

									mHealth.util.showMask();
									mHealth.MedicationControllerObject.service.getResponse(mHealth.env.medication_url	+ '?filter=' + mHealth.MedicationControllerObject.currentMeds, mHealth.MedicationControllerObject.medicationArchSuccess, mHealth.MedicationControllerObject.medicationFailure, true);
								});
					}

				} else if ($('.archieved_avail option[value="Yes"]:selected').val() == 'Yes') {
					mHealth.Medication.source = 'Claims';
					var medicationId = $('.archieved_avail option[value="Yes"]:selected').attr('title');
					var medicationObject = mHealth.models.MedicationModel.findByAttribute('medicationID', medicationId);
					mHealth.Medication.medicationDesc = medicationObject.medicationName;
					mHealth.Medication.medicationId = medicationId;
					mHealth.Medication.medicationName = medicationObject.medicationName;
					mHealth.Medication.strength = medicationObject.strength;
					mHealth.Medication.route = medicationObject.route;
					mHealth.Medication.form = medicationObject.form;
					$.mobile.changePage("../../home/view/addmedication.html");
				}
			},

			addMedicationPageShow : function() {
				$('#frequencyOther').hide();
				$('#refilFrequencyOther').hide();
				
				
				if(mHealth.Medication.dosage!='Dosage')
					{
					  $('#dosageAmount').find("option[value='"+mHealth.Medication.dosage+"']").attr('selected','selected');
					  $('#dosageAmount').selectmenu('refresh');
					}
				if(mHealth.Medication.freqId!="")
					{
				    	$('#frequency').find("option[value='"+mHealth.Medication.freqId+"']").attr('selected','selected');
				        $('#frequency').selectmenu('refresh');
					}
				
				if(mHealth.Medication.startDate!="")
					{
				    	$("#startDate").val(mHealth.Medication.startDate);
					}
				if (this.detailedMedications != undefined|| this.detailedMedications != null) {
					if (this.detailedMedications.freqId == '24') {
						$('#frequencyOther').show();
					}
					if (this.detailedMedications.refillFreqId == '5') {
						$('#refilFrequencyOther').show();
					}
				}
			},
			/**
			 * Name : addMedicationPostProcess Purpose : pagebefore show
			 * processing of the add Medication Params : -- Returns : --
			 */
			addMedicationPostProcess : function(event) {
				if (!isAndroid) {
					mHealth.mobiscrollutil.mobiScollDateForMedication('#startDate');
					mHealth.mobiscrollutil.mobiScollDateForMedication('#endDate');
				}
				$('#addMedicationDiv').html(_.template($('#medication_script').html()));

				$('#add_medication').trigger('create');

				$('#frequencyList').html(_.template($('#frequencyListScript').html()));

				$('#add_medication').trigger('create');
			},

			/**
			 * Name : showArchievedMedication Purpose : Method to Display the
			 * Archived Medication page Params : -- Returns : --
			 */
			showArchievedMedication : function(event) {
				mHealth.util.logMessage('On the archieved Medication Page');
				mHealth.models.MedicationModel.destroyAll();
				mHealth.util.showMask();
				this.service.getResponse(mHealth.env.medication_url	+ '?filter=disregarded', this.proxy(this.medicationArchievedSuccess), this.proxy(this.medicationFailure), true);
			},

			medicationArchievedSuccess : function(output) {
				
				mHealth.util.logMessage('Inside Archieved Medication Success method');

				var response = output.responseText;

				var medicationData = JSON.parse(response);

				this.proxy(this.setMedicationDataAlone(medicationData.ClaimMedicationList));
			
				this.service.getResponse(mHealth.env.medication_url	+ '?filter=' + this.discontinuedMeds, this.proxy(this.archievedDisContinueSuccess), this.proxy(this.medicationFailure), true);
			
			},

			archievedDisContinueSuccess : function(output) {

				mHealth.util.logMessage('Inside Archieved Medication Success method');

				var response = output.responseText;
				var medicationData = JSON.parse(response);

				this.proxy(this.setMedicationDataAlone(medicationData.MedicationList));

				mHealth.util.hideMask();

				$.mobile.changePage("medicationarchieved.html");
			},

			/**
			 * Name : showClaimMedication Purpose : Method to Display the
			 * medication Claim page Params : -- Returns : --
			 */
			showClaimMedication : function(event) {
				mHealth.util.logMessage('On the claim Medication Page');
				mHealth.util.showMask();
				this.service.getResponse(mHealth.env.medication_url	+ '?filter=' + this.reconileMeds, this.proxy(this.medicationClaimSuccess), this	.proxy(this.medicationFailure), true);
				
			},

			/**
			 * Name : medicationSuccess Purpose : Success callback of medication
			 * service call Params : output - response from the server Returns : --
			 */
			medicationClaimSuccess : function(output) {
				mHealth.util.logMessage('Inside Claim Medication Success method');
				var response = output.responseText;
				var medicationData = JSON.parse(response);
				this.proxy(this.setMedicationData(medicationData.ClaimMedicationList));
				mHealth.Medication.source = 'claim';
				$.mobile.changePage("medicationclaim.html");
				mHealth.Medication.claim = mHealth.models.MedicationModel.count();
				mHealth.util.hideMask();
			},

			/**
			 * Name : displayMedication Purpose : Method to Display the new
			 * medications RFC Params : -- Returns : --
			 */
			displayMedication : function(event) {
				$.mobile.changePage("../view/medications.html");
			},

			/**
			 * Name : removeMedicationModel Purpose : Method to remove the
			 * medications from model Params : -- Returns : --
			 */
			removeMedicationModel : function(event) {
				mHealth.util.logMessage('Inside removeMedicationModel method');
				var eventTarget = event.target;
				var medication_ID = $(eventTarget).parents().children('input[type="hidden"]').val();
				mHealth.util.customPrompt(mHealth.Medication.medRemoveAlert,function() {
					$('.deletebutton').hide();				
								},
								function() {
									var medicationObject = mHealth.models.MedicationModel.findByAttribute('medicationId',medication_ID);

									var enddate = medicationObject.endDate;
									mHealth.util.logMessage('Inside removeMedicationModel method ENDDATE is ::'	+ enddate);

									if (enddate == undefined || enddate == '') {
										var currentDate = mHealth.util.getCurrentDay();
										var todayDt = (new Date()).format(mHealth.datedashformat);

										enddate = todayDt;
										mHealth.util.logMessage('Inside removeMedicationModel method ENDDATE222222 is ::'+ enddate);

									}
									var medicationId = medicationObject.medicationId;
									var partMedId = medicationObject.partMedId;

									var body = '[{ "discontinueReasonId":"211","endDate":"'+ enddate+ '","medicationID":"'+ medicationId+ '","partMedId":"'	+ partMedId + '" }]';

									mHealth.util.logMessage('AFTER removeMedicationModel method AFTER CREATING OBJECT'+ body);

									mHealth.MedicationControllerObject.service.postRequest(mHealth.env.medication_url,body,mHealth.MedicationControllerObject.archiveMedicationSuccess,	mHealth.MedicationControllerObject.medicationFailure,false);
									mHealth.models.MedicationModel.destroy(medicationObject.id);
									mHealth.MedicationControllerObject.renderMedication();
								});
			},
			/**
			 * Name: addMedicationSuccess Purpose: success callback function for
			 * Adding Medication Data : output from postRequest as implicit
			 * param Returns: Doesn't return
			 */
			archiveMedicationSuccess : function(output) {

				mHealth.util.logMessage('On archiveMedicationSuccess function'	+ output.responseText);
				$.mobile.changePage("../../home/view/medicationindex.html");
				mHealth.util.hideMask();
			},

		

			/**
			 * Name : confirmRemoveMedication Purpose : Method to confirmation
			 * to remove the medication Params : -- Returns : --
			 */
			confirmRemoveMedication : function(event) {
				mHealth.util.logMessage('Inside confirmRemoveMedication method');
				var etarget = event.target;
				var image = $(etarget).attr('src');
				$(etarget).attr('src', '../../../assets/images/delete.png');
				$(etarget).parents('.deleteicon').siblings('.ui-block-c').children('.deletebutton').hide();
				$(etarget).parents('.deleteicon').siblings('.ui-block-c').children('.dose').show();
			},
			/**
			 * Name : removeMedication Purpose : Method to remove the
			 * medications Params : -- Returns : --
			 */
			removeMedication : function() {

				mHealth.util.logMessage('Inside removeMedication method');
				$('#removeMedication').hide();
				$('.doneBut').show();
				$('.backBut').hide();
				$('.cancelBut').show();
				mHealth.MedicationControllerObject.showremoveimage = true;
				$('.dosecontainer').css({
					'width' : '25%'
				});
				this.proxy(this.renderMedication());
				$('.deletebutton').hide();

			},

			/**
			 * Name : getAllMedicationsList Purpose : Method to fetch the
			 * CURRENT medication history If we dont pass any filter Datapower
			 * would return only the current medications. Returns : --
			 */
			getAllMedicationsList : function() {
				mHealth.util.logMessage('Inside getAllMedicationsList method');
				mHealth.util.showMask();
				this.service.getResponse(mHealth.env.medication_url	+ '?filter=' + this.allMeds, this.proxy(this.medicationSuccess), this.proxy(this.medicationFailure), true);
			},

			/**
			 * Name : getMedicationList Purpose : Method to fetch the CURRENT
			 * medication history Params : -- Returns : --
			 */
			getMedicationList : function() {
				mHealth.util.logMessage('Inside getMedicationList method');
				mHealth.util.showMask();
				this.service.getResponse(mHealth.env.medication_url	+ '?filter=' + this.currentMeds, this.proxy(this.medicationSuccess), this.proxy(this.medicationFailure), true);
			},
			/**
			 * Name : getDiscMedicationList Purpose : Method to fetch the
			 * Discontinued Medication history Params : -- Returns : --
			 */
			getDiscMedicationList : function() {
				mHealth.util.logMessage('Inside getDiscMedicationList method');
				mHealth.util.showMask();
				this.service.getResponse(mHealth.env.medication_url	+ '?filter=' + this.discMeds, this.proxy(this.medicationSuccess), this.proxy(this.medicationFailure), true);
			},

			/**
			 * Name : getReconMedicationList Purpose : Method to fetch the
			 * Discontinued Medication history Params : -- Returns : --
			 */
			getReconMedicationList : function() {
				mHealth.util.logMessage('Inside getReconMedicationList method');
				mHealth.util.showMask();
				this.service.getResponse(mHealth.env.medication_url+ '?filter=' + this.reconileMeds, this.proxy(this.medicationSuccess), this.proxy(this.medicationFailure), true);
			},
			/**
			 * Name : getDisregMedicationList Purpose : Method to fetch the
			 * Disregared MedicationList Params : -- Returns : --
			 */
			getDisregMedicationList : function() {
				mHealth.util.logMessage('Inside getDisregMedicationList method');
				mHealth.util.showMask();
				this.service.getResponse(mHealth.env.medication_url	+ '?filter=' + this.disregMeds, this.proxy(this.medicationSuccess), this.proxy(this.medicationFailure), true);
			},

			/**
			 * Name : medicationSuccess Purpose : Success callback of medication
			 * service call Params : output - response from the server Returns : --
			 */
			medicationSuccess : function(output) {
				mHealth.util.logMessage('Inside medicationSuccess method');
				var response = output.responseText;
				var medicationData = JSON.parse(response);
				this.proxy(this.setMedicationData(medicationData.MedicationList));
				$.mobile.changePage("../view/medicationindex.html");
				mHealth.util.hideMask();
			},
			/**
			 * Name : medicationFailure Purpose : Error callback of medication
			 * service call Params : jqXHR - XMLHttpRequestObject, textStatus -
			 * Status text message of the response, errorThrown - Error message
			 * recieved from the server Returns : Alerts 'Information not
			 * available'
			 */
			medicationFailure : function(jqXHR, textStatus, errorThrown) {
				mHealth.util.logMessage('Inside medicationFailure method');
				mHealth.util.hideMask();
				mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
			},

			/**
			 * Name : renderMedication Purpose : Method to show medication list.
			 * Params : -- Returns : --
			 */
			renderMedication : function() {
				mHealth.util.logMessage('Inside renderMedication method');
				var medicationData;
				medicationData = mHealth.models.MedicationModel.all();
				$('#data_div').html(_.template($('#medicationDataList').html(), {
							medicationData : medicationData
					}));
				$('#medListDiv').css({
					'width' : '100%'
				});
				$('dosecontainer').css({
					'width' : '0%'
				});

				$('#medication_index').trigger('create');
			},

			/**
			 * Name : showMedicationList Purpose : Method to render the
			 * medication history in the view Params : -- Returns :
			 * medicationData
			 */
			showMedicationList : function() {
				
				mHealth.Medication.freqId="";
				mHealth.Medication.startDate="";
				mHealth.Medication.dosage="Dosage";
				mHealth.util.logMessage('Inside showMedicationList method');
				$('.cancelBut').hide();
				$('.backBut').show();
				$('.doneBut').hide();
				if (mHealth.models.MedicationModel.all() != "") {
					$('#removeMedication').show();
				} else {
					$('#removeMedication').hide();
				}
				this.proxy(this.renderMedication());
			},

			/**
			 * Name : getDetailedMedication Purpose : Method to get the detailed
			 * view of medication data Params : event object Returns :
			 * detailedMedications
			 */
			getDetailedMedication : function(event) {
				mHealth.util.logMessage('Inside getDetailedMedication method');
				var detailedMedication;
				var eventTarget = event.target;
				var medication_ID = "";
				if (($(eventTarget).hasClass("medicationUniqueId"))) {
					medication_ID = $(eventTarget).children('input[type="hidden"]').val();
				} else if (!($(eventTarget).hasClass("del-text"))&& !($(eventTarget).hasClass("deletesource"))) {
					medication_ID = $(eventTarget).parents().children('input[type="hidden"]').val();
				}
				if (medication_ID) {
					mHealth.models.MedicationModel.select(function(record) {
						if (record.medicationId == medication_ID) {
							detailedMedication = record;
						}
					});
					this.detailedMedicationstring = JSON.stringify(detailedMedication);
					var encodeMedicationData = $.base64Encode(this.detailedMedicationstring);
					this.detailedMedicationstring=encodeMedicationData;
					//TODO: Need to remove the query from this to make it work on Android 3.0 and above.
					$.mobile.changePage("../view/medicationdetails.html");
				}
			},

			/**
			 * Name : showDetailedMedication Purpose : Method to render the
			 * detailed view of medication data Params : -- Returns :
			 * detailedMedications
			 */
			showDetailedMedication : function() {
				mHealth.util.logMessage('Inside showDetailedMedication method');
				
				medicationData = $.base64Decode(this.detailedMedicationstring);
				
				this.detailedMedications = JSON.parse(medicationData);

				$('#startDate').val(this.detailedMedications.startDate);
				
				$('#endDate').val(this.detailedMedications.endDate);

				if (!isAndroid) {
					mHealth.mobiscrollutil.mobiScollDateForMedication('#startDate');
					mHealth.mobiscrollutil.mobiScollDateForMedication('#endDate');
				}

				this.frequency = this.detailedMedications.frequency;

				$('#detailed_data').html(_.template($('#medicationDetails').html(), {
							detailedMedications : this.detailedMedications
						}));
				$('#detailed_data1').html(_.template($('#medicationDetails1').html(), {
							detailedMedications : this.detailedMedications
						}));
				$('#detailed_data2').html(_.template($('#medicationDetails2').html()));

				$('#detail_medication').trigger('create');
			},

			/**
			 * Name : setMedicationData Purpose : Method to set the data from
			 * server to the medication model Params : response - response data
			 * from the server Returns : --
			 */
			setMedicationDataAlone : function(response) {
				mHealth.util.logMessage('Inside setMedicationData method');
				mHealth.models.MedicationModel.customFromJSON(response);
			},

			/**
			 * Name : setMedicationData Purpose : Method to set the data from
			 * server to the medication model Params : response - response data
			 * from the server Returns : --
			 */
			setMedicationData : function(response) {
				mHealth.util.logMessage('Inside setMedicationData method');
				mHealth.models.MedicationModel.destroyAll();
				mHealth.models.MedicationModel.customFromJSON(response);
			}
		});
