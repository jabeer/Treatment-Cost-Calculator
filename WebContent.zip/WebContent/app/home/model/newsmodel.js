/* Models for News*/
//mHealth.models.NewsModel = Spine.Model.sub();
//mHealth.models.NewsModel.configure("NewsModel",'categories', 'name', 'primaryDisplay', 'articles', 'name', 'title', 'created', 'article_type', 'teaser', 'copyright', 'id');


mHealth.models.CategoryModel = Spine.Model.sub();
mHealth.models.CategoryModel.configure("CategoryModel",'name','priorityCategory', 'articles');

mHealth.models.ArticleModel = Spine.Model.sub();
mHealth.models.ArticleModel.configure("ArticleModel", 'name', 'title', 'created', 'article_type', 'teaser', 'copyright', 'id', 'isread');


//
//mHealth.models.ArticleTestModel = Spine.Model.sub();
//mHealth.models.ArticleTestModel.configure("ArticleTestModel", 'name', 'title');

/*
 {
 "categories": [
    {
    "name": "diabetes",
    "priorityCategory": "true",
    "articles": [
            {
            "name": "668431",
            "title": "Put Traffic Safety on Back-to-School 'To-Do' List: Experts",
            "created": "09/09/2012",
            "uri": "/service/custom/download.json?id=workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4",
            "article_type": "News",
            "teaser": "Kids, whether traveling by bus, bike, car or foot, should be taught how to avoid accidents",
            "copyright": "Copyright © 2012 <a href=\"http://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.",
            "id": "workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4",
            "isread": "false"
            },
            {
            "name": "667978",
            "title": "Water or Sports Drink?",
            "created": "09/09/2012",
            "uri": "/service/custom/download.json?id=workspace://SpacesStore/cf1b0433-e289-4495-bb9f-4fc94c26af9d",
            "article_type": "News",
            "teaser": "Plain old H2O is usually the better choice, expert says",
            "copyright": "Copyright © 2012 <a href=\"http://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.",
            "id": "workspace://SpacesStore/cf1b0433-e289-4495-bb9f-4fc94c26af9d",
            "isread": "false"
            },
            {
            "name": "668451",
            "title": "Tight Blood Sugar Control Won't Help Babies After Heart Surgery",
            "created": "09/08/2012",
            "uri": "/service/custom/download.json?id=workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176",
            "article_type": "News",
            "teaser": "Infection rates, survival didn't change, but more risk for low blood sugar seen in study",
            "copyright": "Copyright © 2012 <a href=\"http://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.",
            "id": "workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176",
            "isread": "false"
            },
        ] //close articles
    },
    {
    "name": "asthma",
    "priorityCategory": "false",
    "articles": [
            {
            "name": "668431",
            "title": "Put Traffic Safety on Back-to-School 'To-Do' List: Experts",
            "created": "09/09/2012",
            "uri": "/service/custom/download.json?id=workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4",
            "article_type": "News",
            "teaser": "Kids, whether traveling by bus, bike, car or foot, should be taught how to avoid accidents",
            "copyright": "Copyright © 2012 <a href=\"http://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.",
            "id": "workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4",
            "isread": "false"
            },
            {
            "name": "667978",
            "title": "Water or Sports Drink?",
            "created": "09/09/2012",
            "uri": "/service/custom/download.json?id=workspace://SpacesStore/cf1b0433-e289-4495-bb9f-4fc94c26af9d",
            "article_type": "News",
            "teaser": "Plain old H2O is usually the better choice, expert says",
            "copyright": "Copyright © 2012 <a href=\"http://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.",
            "id": "workspace://SpacesStore/cf1b0433-e289-4495-bb9f-4fc94c26af9d",
            "isread": "false"
            },
            {
            "name": "668451",
            "title": "Tight Blood Sugar Control Won't Help Babies After Heart Surgery",
            "created": "09/08/2012",
            "uri": "/service/custom/download.json?id=workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176",
            "article_type": "News",
            "teaser": "Infection rates, survival didn't change, but more risk for low blood sugar seen in study",
            "copyright": "Copyright © 2012 <a href=\"http://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.",
            "id": "workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176",
            "isread": "false"
            }
        ] //close articles
       }
    ]  //close categories
 }

 var response = '{"categories": [{"name": "diabetes", "priorityCategory": "true",  "articles": [{"name": "668431","title": "Put Traffic Safety on Back-to-School To-Do List: Experts","created": "09/09/2012","uri": "/service/custom/download.json?id=workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4","article_type": "News","teaser": "Kids, whether traveling by bus, bike, car or foot, should be taught how to avoid accidents","copyright": "Copyright © 2012 <a href=\"httpXXX://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.","id": "workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4","isread": "false"},{"name": "667978","title": "Water or Sports Drink?","created": "09/09/2012","uri": "/service/custom/download.json?id=workspace://SpacesStore/cf1b0433-e289-4495-bb9f-4fc94c26af9d","article_type": "News","teaser": "Plain old H2O is usually the better choice, expert says","copyright": "Copyright © 2012 <a href=\"httpXXX://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.","id": "workspace://SpacesStore/cf1b0433-e289-4495-bb9f-4fc94c26af9d","isread": "false"},{"name": "668451","title": "Tight Blood Sugar Control Wont Help Babies After Heart Surgery","created": "09/08/2012","uri": "/service/custom/download.json?id=workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176","article_type": "News","teaser": "Infection rates, survival didnt change, but more risk for low blood sugar seen in study","copyright": "Copyright © 2012 <a href=\"httpXXX://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.","id": "workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176","isread": "false"},]},{"name": "asthma","priorityCategory": "false","articles": [{"name": "668431","title": "Put Traffic Safety on Back-to-School To-Do List: Experts","created": "09/09/2012","uri": "/service/custom/download.json?id=workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4","article_type": "News","teaser": "Kids, whether traveling by bus, bike, car or foot, should be taught how to avoid accidents","copyright": "Copyright © 2012 <a href=\"httpXXX://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.","id": "workspace://SpacesStore/fdce8acb-e93f-4424-8439-2de2cb6d16e4","isread": "false"},{"name": "668451","title": "Tight Blood Sugar Control Wont Help Babies After Heart Surgery","created": "09/08/2012","uri": "/service/custom/download.json?id=workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176","article_type": "News","teaser": "Infection rates, survival didnt change, but more risk for low blood sugar seen in study","copyright": "Copyright © 2012 <a href=\"httpXXX://www.healthday.com/\" target=\"_new\">HealthDay</a>. All rights reserved.","id": "workspace://SpacesStore/8a074ba8-3568-49c0-8cd3-9564efa32176","isread": "false"}]}]}';

*/