mHealth.models.MedicationModel = Spine.Model.sub();
mHealth.models.MedicationModel.configure("MedicationModel",'participantId','partMedId','medicationId','medicationName','startDate',
		'endDate','strength','dosage','nextRefillDate','medicationType',
		'route','form','source','complianceStatus','comments','compliance','cdrRunid','dispDate','medicationID', 'ndcId', 'rxClaimId', 'rxDaysSupply', 'rxQuantity','refillFreqId','freqId','freqDesc','refillFrequencyOther','otherFreq');

mHealth.models.MonographModel = Spine.Model.sub();
mHealth.models.MonographModel.configure('MonographModel', 'medicationId', 'medicationMonograph' );
   

    
 