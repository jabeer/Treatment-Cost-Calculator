mHealth.models.ConditionModel =  Spine.Model.sub();
mHealth.models.ConditionModel.configure('ConditionModel','participantId',
'memberEligId','participantConditionId','icd9Id','conditionName','subConditionName',
'diagnosisDate','conditionComment','statusId','sourceId','applicationId');


mHealth.models.SearchConditionModel = Spine.Model.sub();
mHealth.models.SearchConditionModel.configure('SearchConditionModel','conditionName','icd9Id', 'SubCondition');

mHealth.models.ConditionModel.include({

validate:function(){
if (this.icd9Id===''){
return 'please enter condition';

}




}



});

