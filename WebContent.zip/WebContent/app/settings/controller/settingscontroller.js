/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.SettingsController = Spine.Controller.sub({
	el : 'body',
	hwarticleID : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	deviceInfo : null,
	toc  :null,
	events : {
		'click #logoutId'              : 'doLogout',
        'click #showAbout'             : 'getFeatures', 
		'click #sendFeedBack'          : 'sendMail',
		'pagebeforeshow #aboutsDetail' : 'showDetail',
		'change #HeightUnit'           : 'getHeightUnits',
		'change #WeightUnit'           : 'getWeightUnits',
		'pagebeforeshow #settingsPage' : 'showSettings',
		'pageshow #settingsPage'       : 'viewTabbar',
		'click #debugId'               : 'debug',
		'pagehide #tandcPageId'        : 'removeTermsOfUseScroll',
		'pagehide #displaytermsofUsePage':'removeTermsOfUseScroll',
		'click #measurementUnits'        : 'setDocHeight',
        'click #aboutTermsOfUse'         : 'displayTermsOfUse',
        'pagebeforeshow #displaytermsofUsePage' : 'displaytermsofUsePage',
        'pageshow #displaytermsofUsePage'       : 'addScrollTermsOfUse'
    },
      /**
       * Name    : displaytermsofUsePage and displayTermsOfUse
       * Purpose : Preload content of the rootview/view/termsofuse.html into the displaytermsofuse.html
       * Params  : --
       * Return  : --
       * Comment : rootview/view/termsofuse.html is a single page that is being shared by rootview/view/termsandconditons.html and settings/view/displaytermsofuse.html.   Content of that page are populated into respective <div> of the previously mentioned pages
       **/
    displaytermsofUsePage : function(){
//        $('#displayTermsOfUse').load('../../rootview/view/termsofuse.html');
//    	if(this.toc==null){//tou_get_url
//            this.service.getTOC(mHealth.env.tou_get_url,this.proxy(this.termsOfUseSuccess));
//            //this.service.getTOC('http://secure.uat.alerehealth.com:13085/api/tou/',this.proxy(this.termsOfUseSuccess));
//                                                              
//    	}
        $.ajax({
        url : "https://img.uat.alerehealth.com/imageserver/alere/mobile/termsofuse.html", 
        async : true, type : 'GET', timeout : mHealth.service_timeout,
        success : function(output, textStatus, jqXHR){
            $('#displayTermsOfUse').append(output).trigger("create"); 
        },
        complete : function(output) {},
         error : function(jqXHR, textStatus, errorThrown) {
         //alert('Inside the error'+errorThrown);
        },
        beforeSend : function(xhr) {}
    });                                                              
    	
    },
    termsOfUseSuccess : function(output)
    {
    	this.toc = output.responseText;
    	$('#displayTermsOfUse').append(output.responseText);
        $('#displaytermsofUsePage').trigger('create');
    	
    },
    displayTermsOfUse : function() {
    	$.mobile.changePage('../../settings/view/displaytermsofuse.html');
    },                                                        
	/**
	 * Name    : viewTabbar
	 * Purpose : Method to viewTabbar
	 * Params  : --
	 * Return  : --
	 **/
	viewTabbar : function() {
		if (isAndroid ) {
		    Android.showTab();
		}
		else if(isIOS){
			mHealth.util.unloadChart();
			mHealth.util.showTabBar();
		} 
		else{
		//Browser Implementation	
		}
		
	},

	/**
	 * Name    : setDocHeight
	 * Purpose : Method to set document height to fix white strip.
	 * Params  : --
	 * Return  : --
	 **/
	setDocHeight : function() {

		$('#settingsPage').css({
			'height' : 'auto'
		});
		$('#settingsPage').trigger('create');
    },
    /**
    * Name    : addScrollTermsOfUse
    * Purpose : Method to bind the touchmove for scrolling to work after loading display terms of use page.
    * Params  : --
    * Return  : --
    **/
    addScrollTermsOfUse : function() {
        $('#termsofuseScroll').css({
            'height': '100%'
        });
        mHealth.util.logMessage("Building the scroll for Display Terms of Use Page");
        mHealth.util.touScroll = new iScroll('termsofuseScroll', {
           bounce : false,
           checkDOMChanges: false
        });
        $(document).bind('touchmove', mHealth.util.prevDefault());
    },
    /**
	 * Name    : removeTermsOfUseScroll
	 * Purpose : Method to unbind the touchmove for scrolling to work after going out of terms of use page.
	 * Params  : --
	 * Return  : --
	 **/
	removeTermsOfUseScroll : function() {
		mHealth.util.logMessage("Going out of the page terms of Use");
		$(document).unbind('touchmove', mHealth.util.prevDefault());
    },      
	/**
	 * Name    : debug
	 * Purpose : Method to do Debug.
	 * Params  : --
	 * Return  : --
	 **/
	debug : function() {
		$.mobile.changePage('../../debug/view/debugindex.html');
	},
	/**
	 * Name    : cleanObject
	 * Purpose : Method to do destroy all the object
	 * Params  : --
	 * Return  : --
	 **/
	
	cleanObject: function() {
		mHealth.models.ConditionModel.destroyAll();
		mHealth.models.MedicationModel.destroyAll();
		mHealth.models.ParticipantModel.destroyAll();
		mHealth.models.HealthDataModel.destroyAll();
		mHealth.models.FeatureGroupModel.destroyAll();
//		mHealth.models.NewsModel.destroyAll();
        
        //MODELS FROM RootView
        mHealth.models.SpaceModel.destroyAll();
		mHealth.models.ZoneModel.destroyAll();
		mHealth.models.ViewModel.destroyAll();
        mHealth.models.SpaceViewZoneModel.destroyAll();
		//MODELS FROM Activities
        mHealth.models.ChallengeResponseModel.destroyAll();
		mHealth.models.QuestionResponsesModel.destroyAll();
        mHealth.models.ChallengeModel.destroyAll();
        mHealth.models.QuestionsModel.destroyAll();
        
        // MODELS FROM MESSAGE
        mHealth.models.MessageModel.destroyAll();
        mHealth.models.MessageDetailsResponse.destroyAll();
        mHealth.models.MessageDetailsModel.destroyAll();
                              
        mHealth.models.MessageSectionModel.destroyAll();
        mHealth.models.QuestionnaireModel.destroyAll();
        mHealth.models.QuestionGroupModel.destroyAll();
        mHealth.models.MessageQuestionModel.destroyAll();
        mHealth.models.QuestionMsgModel.destroyAll();
        mHealth.models.MessageAnswerModel.destroyAll();
        mHealth.models.ArchiveModel.destroyAll();
        mHealth.models.UserFeedbackModel.destroyAll();
                              
        //CLEANING UP VARIABLES
                              
        mHealth.controllers.ActivityController.spaceviewZone = null;
        mHealth.controllers.ActivityController.subActivityView = null;
        mHealth.controllers.ActivityController.activity = null;
        mHealth.controllers.ActivityController.activityDetailRecord= null;
		mHealth.util.messageCenter=null;
                              
		$('#loginPage').detach();
		//Removing the different mobile.changepage to single statement for the all the platform 
		
		$.mobile.changePage("../../rootview/view/login.html");
		mHealth.util.removeNativeBar();
		mHealth.MessageControllerObject.tabbarloaded = false;
	},
	
	
	/**
	 * Name    : doLogout
	 * Purpose : Method to do required actions while logout.
	 * Params  : --
	 * Return  : --
	 **/
	doLogout : function() {
		var splashMessage = mHealth.SettingsLogin.logout;
		mHealth.util.splashMessage=splashMessage;
		
		mHealth.util.customPrompt(mHealth.SettingsController.logoutConfirm, function() {
		}, function() {
			mHealth.SettingsControllerObject.cleanObject();
		});
	},
	/**
	 * Name    : getHeightUnits
	 * Purpose : Method to get the selected value of height units field on change of the select menu
	 * Params  : --
	 * Return  : --
	 **/
	getHeightUnits : function() {
		mHealth.util.selUnits = $('select#HeightUnit option:selected').val();
	},
	/**
	 * Name:WeightUnits
	 *Purpose:Method to get the selected value of weight units field
	 on change of the select menu
	 **/

	getWeightUnits : function() {
		mHealth.util.selWeightUnits = $('select#WeightUnit option:selected').val();
	},
	/**
	 * Name    : showSettings
	 * Purpose : Method to render the selected value of height units field on load of the page
	 * Params  : --
	 * Return  : --
	 **/
	showSettings : function() {
		mHealth.util.logMessage('Inside the show Settings');
		var hasDebug=false;
		var response = mHealth.models.FeatureGroupModel.findByAttribute("groupId", "misc");
		
		if ( typeof response.feature != "undefined" && response.feature != "") {
			var length = response.feature.length
			for(var i = 0; i < length; i++) {
				if(response.feature[i].id != undefined) {
					if(response.feature[i].id == 'debug') {
						hasDebug = true;
						break;
					}
				}
			}
		}
		mHealth.util.logMessage('render the Settings page');
		$('#debug').html(_.template($('#debug_script').html(), {
			hasDebug : hasDebug
		}));
		$('#settingsPage').trigger('create');

		if(mHealth.util.selUnits == 'cm') {
			$("select#HeightUnit option[value='cm']").attr("selected", "selected");
			$('select').selectmenu('refresh');
		}
		if(mHealth.util.selWeightUnits == 'Kg') {
			$("select#WeightUnit option[value='Kg']").attr("selected", "selected");
			$('select').selectmenu('refresh');
		}

	},
	/**
	 * Name    : showDetail
	 * Purpose : Method to render the values of device details
	 * Params  : --
	 * Return  : settingsDetail, deviceInfo
	 **/
	showDetail : function() {
		var settingsDetail;
		settingsDetail = mHealth.SettingsAbout;
		$('#settingsHeader').html(_.template($('#headerScript').html(), {
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').html(_.template($('#deviceDetails').html(), {
			deviceInfo : deviceInfo,
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').trigger('create');
		$('#settingsHeader').trigger('create');

	},
	/**
	 * Name    : getFeatures
	 * Purpose : Method to call the webview to get Device Features
	 * Params  : --
	 * Return  : --
	 **/
	getFeatures : function() {
        //mHealth.util.getDeviceFeatures(); // This Method is define in Native Bridge
        // Commenting the above line as it is now been called during launch of Login Page
		$.mobile.changePage("about.html");
	},
    
    /**
	 * Name    : sendMail
	 * Purpose : Method to call the webview to call native email
	 * Params  : --
	 * Return  : --
	 **/
	sendMail : function() {
		mHealth.util.sendEmail(mHealth.env.emailTo, mHealth.env.emailCC, mHealth.env.emailSubject);
	}
});

mHealth.controllers.SettingsController.extend({
	/**
	 * Name    : getDeviceGlobalSettings
	 * Purpose : Method to call from webview to get device features
	 * Params  : --
	 * Return  : --
	 * Comments: This method is been called from nativeBridge getDeviceInfo()
	 **/
	getDeviceGlobalSettings : function( osId,osVersion,deviceMake,deviceModel,deviceId, deviceToken,deviceName,appName) {  
		mHealth.util.logMessage('getDeviceGlobalSettings in settingscontroller' + deviceToken);
		mHealth.util.osId 	     = osId;
	 	mHealth.util.osVersion 	 = osVersion;
	 	mHealth.util.devMake 	 = deviceMake; 
	 	mHealth.util.devModel 	 = deviceModel;
        mHealth.util.devCustId 	 = deviceId; 
        mHealth.util.devicetoken = deviceToken;
        mHealth.util.deviceName  = deviceName; 
        mHealth.util.appName 	 = appName;
        mHealth.util.appVersion  = appName;
     	
        if(isIOS){
        	mHealth.util.platform = 'Apple';
        }else if(isAndroid){
        	mHealth.util.platform = 'Android';
        }else{
        	mHealth.util.platform = 'Browser';
        }
       // TODO CLEAN UP THE FOLLOWING OBJECT LOTS OF UNWANTED
        deviceInfo = [{
        	'osId' 		    : mHealth.util.osId,
        	'osVersion' 	: mHealth.util.osVersion,
        	'deviceMake'	: mHealth.util.devMake,
        	'deviceModel'	: mHealth.util.devModel,
        	'deviceId' 		: mHealth.util.udid,
        	'deviceTokenId' : mHealth.util.devicetoken,
			'deviceName' 	: mHealth.util.deviceName,//device specific name - Setting/General/About/Name
			'appName' 		: mHealth.util.appName,
			'regUser' 		: mHealth.util.participantEmail,
            'appVersion' 	: mHealth.util.appName,
			'devCustId' 	: mHealth.util.devCustId,     //Custom ID, combo as deviceName+osName
            'platform' 		: mHealth.util.platform
		}];
	}
});