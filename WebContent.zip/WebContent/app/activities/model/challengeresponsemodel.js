mHealth.models.ChallengeResponseModel=Spine.Model.sub();
mHealth.models.ChallengeResponseModel.configure('ChallengeResponseModel','MeasurementDate','QuestionResponse');

mHealth.models.QuestionResponsesModel=Spine.Model.sub();
mHealth.models.QuestionResponsesModel.configure('QuestionResponsesModel','QuestionID','Answer','Comments');

mHealth.models.ChallengeModel = Spine.Model.sub();
mHealth.models.ChallengeModel.configure('ChallengeModel','ID','Title','IntroCopy','BodyCopy','MaxCredits','EarnedCredits','BeginDate','EndDate','IsEngaged','EarnedPts','NextTierPoints','NextTierCredits','Question');

mHealth.models.QuestionsModel = Spine.Model.sub();
mHealth.models.QuestionsModel.configure('QuestionsModel','ID','Rank','Description','Title','EntryType','Frequency','BeginDate','EndDate');